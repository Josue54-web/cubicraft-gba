#!/usr/bin/env python3
"""Genera source/font.h (fuente 8x8, ASCII 32..126) a partir de DejaVu Sans Mono.
El resultado ya esta incluido en el repo; no hace falta ejecutarlo para compilar."""
from PIL import Image, ImageDraw, ImageFont
import sys
ttf = sys.argv[1] if len(sys.argv) > 1 else "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"
f = ImageFont.truetype(ttf, 8)
out = ["/* Generado por tools/gen_font.py : 95 glifos 8x8, 1bpp, bit7 = pixel izquierdo */",
       "static const unsigned char font8x8[95][8] = {"]
for c in range(32, 127):
    im = Image.new("L", (8, 8), 0)
    d = ImageDraw.Draw(im); d.fontmode = "1"
    d.text((0, 6), chr(c), font=f, fill=255, anchor="ls")
    rows = []
    for y in range(8):
        b = 0
        for x in range(8):
            if im.getpixel((x, y)) > 127: b |= 0x80 >> x
        rows.append(b)
    out.append("  {" + ",".join("0x%02X" % r for r in rows) + "}, /* '%s' */" % (chr(c) if chr(c) not in "\\*/" else "?"))
out.append("};")
open("source/font.h", "w").write("\n".join(out) + "\n")
