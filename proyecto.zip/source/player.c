/* player.c - inventario, crafteo, jugador, acciones (A = minar/atacar/interactuar, B = usar/colocar) */
#include "game.h"

Slot inv[INV_N] EWRAM;
Slot chest_inv[MAX_CHESTS][27] EWRAM;
u16 chest_pos[MAX_CHESTS];
Player P;
u32 ach_mask;
int stat_kills, stat_trades, stat_bred, stat_vis;
char msg_buf[40];
int msg_t;
const s8 DX[4] = {0, -1, 0, 1};
const s8 DY[4] = {1, 0, -1, 0};

void say(const char *s) {
  int i = 0;
  while (s[i] && i < 38) { msg_buf[i] = s[i]; i++; }
  msg_buf[i] = 0;
  msg_t = 150;
}
const char *item_name(u8 id) { return ITM[id].name ? ITM[id].name : "?"; }

/* ------------------------------------------------------------ inventario */
static int stackable(u8 id) {
  int k = ITM[id].kind;
  if (k == K_PICK || k == K_SWORD || k == K_ARMOR || k == K_BOW || k == K_POTION) return 0;
  if (k == K_TOOL) return id == I_SEED;
  return 1;
}
int inv_count(u8 id) {
  int c = 0;
  for (int i = 0; i < INV_N; i++) if (inv[i].id == id) c += inv[i].n;
  return c;
}
int inv_can_add(u8 id, int n) {
  if (!stackable(id)) { for (int i = 0; i < INV_N; i++) if (!inv[i].id) return 1; return 0; }
  int room = 0;
  for (int i = 0; i < INV_N; i++) { if (inv[i].id == id) room += 64 - inv[i].n; else if (!inv[i].id) room += 64; }
  return room >= n;
}
int inv_add(u8 id, int n) {
  if (!id || n <= 0) return 0;
  if (!stackable(id)) {
    for (int k = 0; k < n; k++) {
      int j = -1;
      for (int i = 0; i < INV_N; i++) if (!inv[i].id) { j = i; break; }
      if (j < 0) return n - k;
      inv[j].id = id; inv[j].n = 1; inv[j].dur = ITM[id].dur; inv[j].en = 0;
    }
    return 0;
  }
  for (int i = 0; i < INV_N && n > 0; i++)
    if (inv[i].id == id && !inv[i].en && inv[i].n < 64) { int t = 64 - inv[i].n; if (t > n) t = n; inv[i].n += (u8)t; n -= t; }
  for (int i = 0; i < INV_N && n > 0; i++)
    if (!inv[i].id) { int t = n > 64 ? 64 : n; inv[i].id = id; inv[i].n = (u8)t; inv[i].dur = 0; inv[i].en = 0; n -= t; }
  return n;
}
int inv_take(u8 id, int n) {
  if (inv_count(id) < n) return 0;
  for (int i = INV_N - 1; i >= 0 && n > 0; i--)
    if (inv[i].id == id) { int t = inv[i].n < n ? inv[i].n : n; inv[i].n -= (u8)t; n -= t; if (!inv[i].n) { inv[i].id = 0; inv[i].en = 0; } }
  return 1;
}
static void gain(u8 id, int n) {
  int left = inv_add(id, n);
  if (left) say("Mochila llena");
}

int can_craft(const Recipe *r) {
  if (r->i1 && inv_count(r->i1) < r->n1) return 0;
  if (r->i2 && inv_count(r->i2) < r->n2) return 0;
  if (r->i3 && inv_count(r->i3) < r->n3) return 0;
  if (r->i4 && inv_count(r->i4) < r->n4) return 0;
  return 1;
}
void do_craft(const Recipe *r) {
  if (P.mode != MODE_CREATIVE && !can_craft(r)) return;
  if (!inv_can_add(r->out, r->n)) { say("Mochila llena"); return; }
  if (P.mode != MODE_CREATIVE) {
    if (r->i1) inv_take(r->i1, r->n1);
    if (r->i2) inv_take(r->i2, r->n2);
    if (r->i3) inv_take(r->i3, r->n3);
    if (r->i4) inv_take(r->i4, r->n4);
  }
  inv_add(r->out, r->n);
  say(item_name(r->out));
}

/* ----------------------------------------------------------------- cofres */
int chest_find(int x, int y, int create) {
  u16 key = (u16)(DOFF[cur_dim] + y * DW[cur_dim] + x);
  int fr = -1;
  for (int i = 0; i < MAX_CHESTS; i++) {
    if (chest_pos[i] == key + 1) return i;
    if (!chest_pos[i] && fr < 0) fr = i;
  }
  if (!create || fr < 0) return -1;
  chest_pos[fr] = (u16)(key + 1);
  for (int k = 0; k < 27; k++) { chest_inv[fr][k].id = 0; chest_inv[fr][k].n = 0; chest_inv[fr][k].en = 0; chest_inv[fr][k].dur = 0; }
  if (cur_dim != D_OVER || 1) chest_loot(fr);
  return fr;
}
static void put_chest(int ci, u8 id, int n) {
  for (int k = 0; k < 27; k++) if (!chest_inv[ci][k].id) { chest_inv[ci][k].id = id; chest_inv[ci][k].n = (u8)n; chest_inv[ci][k].dur = ITM[id].dur; return; }
}
void chest_loot(int ci) {
  static const u8 TAB[] = {I_BREAD, I_APPLE, I_COAL, I_IRON, I_GOLD, I_ARROW, I_TORCH, I_SEED, I_CARROT, I_WOOL, I_REDSTONE, I_LAPIS, I_STRING, I_BONE};
  int dim = cur_dim;
  if (dim == D_OVER) { put_chest(ci, I_BREAD, 1 + rnd(3)); if (rnd(2)) put_chest(ci, I_IRON, 1 + rnd(2)); put_chest(ci, TAB[rnd(14)], 1 + rnd(4)); }
  else if (dim == D_CAVE) { put_chest(ci, I_EYE, 1); put_chest(ci, I_DIAMOND, 1 + rnd(2)); put_chest(ci, I_IRON, 2 + rnd(4)); put_chest(ci, I_APPLE, 3); put_chest(ci, I_OBSIDIAN, 2); }
  else { put_chest(ci, I_GOLD, 2 + rnd(4)); put_chest(ci, I_NWART, 2 + rnd(3)); put_chest(ci, I_IRON, 1 + rnd(3)); if (rnd(3) == 0) put_chest(ci, I_DSWORD, 1); put_chest(ci, I_QUARTZ, 2); }
}

/* --------------------------------------------------------------------- xp */
int xp_need(int lvl) { return 5 + lvl * 3; }
void add_xp(int n) {
  P.xp += n;
  while (P.xp >= xp_need(P.lvl)) { P.xp -= xp_need(P.lvl); P.lvl++; say("Subes de nivel!"); }
}

/* ------------------------------------------------------------ colisiones */
static int box_free(int x, int y) {
  const int h = 5 << 4;
  int x0 = (x - h) >> 8, x1 = (x + h - 1) >> 8, y0 = (y - h) >> 8, y1 = (y + h - 1) >> 8;
  for (int ty = y0; ty <= y1; ty++) for (int tx = x0; tx <= x1; tx++) if (!tile_walk(tx, ty)) return 0;
  return 1;
}

/* ------------------------------------------------------------------ init */
void player_init(int mode) {
  for (int i = 0; i < INV_N; i++) { inv[i].id = 0; inv[i].n = 0; inv[i].dur = 0; inv[i].en = 0; }
  for (int i = 0; i < MAX_CHESTS; i++) chest_pos[i] = 0;
  P.mode = (u8)mode;
  P.hp = 20; P.food = 20; P.xp = 0; P.lvl = 0; P.sel = 0; P.dir = 0;
  P.cd = P.hurt = P.swing = 0;
  P.t_speed = P.t_str = P.t_fire = P.t_regen = P.t_night = P.t_res = 0;
  P.hunger_t = P.regen_t = 0; P.mine_hp = 0; P.mine_x = P.mine_y = -1; P.portal_t = 0; P.sleeping = 0;
  P.has_bed = 0; P.dead = 0; P.won = 0; P.fish_t = 0; P.block_t = 0;
  ach_mask = 0; stat_kills = stat_trades = stat_bred = stat_vis = 0;
  cur_dim = D_OVER;
  P.x = spawn_pt[D_OVER].x * 256 + 128; P.y = spawn_pt[D_OVER].y * 256 + 128;
  P.bed.x = spawn_pt[D_OVER].x; P.bed.y = spawn_pt[D_OVER].y;
  game_time = 0; day_t = 2000;
  if (mode == MODE_SURV || mode == MODE_HARD) { inv_add(I_WPICK, 1); inv_add(I_TORCH, 6); inv_add(I_BREAD, 3); }
}

/* ------------------------------------------------------------- armadura */
static Slot *armor_slot(void) {
  for (int i = 0; i < 9; i++) if (inv[i].id && ITM[inv[i].id].kind == K_ARMOR) return &inv[i];
  return 0;
}
int armor_pct(void) {
  Slot *a = armor_slot();
  if (!a) return 100;
  int p = ITM[a->id].a;
  if (EN_T(a) == E_PROT) p -= 5 * EN_L(a);
  return p;
}
static void wear(Slot *s, int amt) {
  if (P.mode == MODE_CREATIVE || !s->id || !ITM[s->id].dur) return;
  if (EN_T(s) == E_UNB && rnd(4) < EN_L(s)) return;
  if (s->dur <= amt) {
    say("Se rompio!");
    s->id = 0; s->n = 0; s->en = 0; s->dur = 0;
  } else s->dur -= (u8)amt;
}
int has_gold_armor(void) { Slot *a = armor_slot(); return a && a->id == I_GARMOR; }

void player_hurt(int dmg, int sx, int sy) {
  if (P.mode == MODE_CREATIVE || P.hurt > 0 || P.dead || P.sleeping) { if (P.sleeping && P.mode != MODE_CREATIVE) P.sleeping = 0; else return; }
  if (P.block_t > 0) { P.hurt = 12; return; }
  int pct = armor_pct();
  if (P.t_res > 0) pct = pct * 6 / 10;
  int d = dmg * pct / 100;
  if (d < 1) d = 1;
  Slot *a = armor_slot();
  if (a) wear(a, 1);
  P.hp -= (s16)d;
  P.hurt = 40;
  P.sleeping = 0;
  if (sx != PX() || sy != PY()) {
    int dx = PX() - sx, dy = PY() - sy;
    int adx = dx < 0 ? -dx : dx, ady = dy < 0 ? -dy : dy;
    int kx = adx > ady ? (dx > 0 ? 5 : -5) : 0, ky = adx > ady ? 0 : (dy > 0 ? 5 : -5);
    if (box_free(P.x + (kx * 16), P.y + (ky * 16))) { P.x += kx * 16; P.y += ky * 16; }
  }
  if (P.hp <= 0) { P.hp = 0; P.dead = 1; }
}

void respawn(void) {
  P.dead = 0; P.hp = 20; P.food = 20; P.hurt = 60;
  P.t_speed = P.t_str = P.t_fire = P.t_regen = P.t_night = P.t_res = 0;
  int tx = P.bed.x, ty = P.bed.y;
  change_dim(D_OVER, tx, ty);
}

/* ------------------------------------------------------------ dimensiones */
static int find_free(int *tx, int *ty) {
  for (int r = 0; r < 6; r++)
    for (int dy = -r; dy <= r; dy++) for (int dx = -r; dx <= r; dx++)
      if (tile_walk(*tx + dx, *ty + dy) && geto(*tx + dx, *ty + dy) == 0) { *tx += dx; *ty += dy; return 1; }
  return 0;
}
void change_dim(int dim, int x, int y) {
  cur_dim = dim;
  find_free(&x, &y);
  P.x = x * 256 + 128; P.y = y * 256 + 128;
  P.mine_hp = 0; P.portal_t = 0;
  ents_clear();
  ents_populate();
  rs_neighbor_changed(-1, -1);
  render_full_redraw();
  static const char *const nm[4] = {"Superficie", "Cuevas", "Nether", "El End"};
  say(nm[dim]);
}

/* ------------------------------------------------------------ logros */
static int hv(u8 a) { return inv_count(a) > 0; }
void check_achievements(void) {
  int c[ACH_N];
  c[0] = hv(I_WOOD) || hv(I_PLANK);
  c[1] = hv(I_WPICK) || hv(I_SPICK) || hv(I_IPICK) || hv(I_DPICK);
  c[2] = hv(I_SPICK) || hv(I_IPICK) || hv(I_DPICK);
  c[3] = hv(I_IRON);
  c[4] = hv(I_DIAMOND);
  c[5] = hv(I_BUCKET) || hv(I_WBUCKET) || hv(I_LBUCKET);
  c[6] = hv(I_WHEAT);
  c[7] = stat_vis > 0;
  c[8] = stat_trades >= 1;
  c[9] = stat_trades >= 10;
  c[10] = stat_bred >= 1;
  c[11] = stat_bred >= 5;
  c[12] = stat_kills >= 20;
  c[13] = P.lvl >= 10;
  c[14] = cur_dim == D_NETH;
  c[15] = cur_dim == D_END;
  c[16] = P.won;
  int ench = 0;
  for (int i = 0; i < INV_N; i++) if (inv[i].id && inv[i].en) ench = 1;
  c[17] = ench;
  for (int i = 0; i < ACH_N; i++)
    if (c[i] && !(ach_mask & (1u << i))) { ach_mask |= 1u << i; say(ACH_NAMES[i]); msg_t = 200; add_xp(1); }
}

/* ----------------------------------------------------------- comer/pociones */
void eat_item(Slot *s) {
  const ItemInfo *it = &ITM[s->id];
  if (s->id == I_RAW && rnd(4) == 0) { P.food -= 2; say("Mal sabor..."); }
  P.food += it->a; if (P.food > 20) P.food = 20;
  P.hp += (s16)(it->a / 2 + 1); if (P.hp > 20) P.hp = 20;
  if (P.mode != MODE_CREATIVE) { s->n--; if (!s->n) { s->id = 0; s->en = 0; } }
}
static void drink(Slot *s) {
  switch (ITM[s->id].a) {
  case 1: P.hp += 6; if (P.hp > 20) P.hp = 20; break;
  case 2: P.t_speed = 7200; break;
  case 3: P.t_str = 7200; break;
  case 4: P.t_fire = 7200; break;
  case 5: P.t_regen = 1800; break;
  case 6: P.t_night = 9000; break;
  case 7: P.t_res = 7200; break;
  }
  if (P.mode != MODE_CREATIVE) { s->id = I_VIAL; s->n = 1; s->en = 0; }
  say("Glug!");
}

/* ------------------------------------------------------------ dano arma */
void held_dmg(int *dmg, int *kb) {
  Slot *s = &inv[P.sel];
  int d = 1, k = 4;
  if (s->id && ITM[s->id].kind == K_SWORD) {
    d = ITM[s->id].a;
    if (EN_T(s) == E_SHARP) d += EN_L(s);
    if (EN_T(s) == E_KNOCK) k += 4 * EN_L(s);
    wear(s, 1);
  } else if (s->id && ITM[s->id].kind == K_PICK) d = 2;
  if (P.t_str > 0) d += 3;
  *dmg = d; *kb = k;
}

/* ----------------------------------------------------------------- minar */
static int mine_power(int *tier) {
  Slot *s = &inv[P.sel];
  int d = 1; *tier = 0;
  if (s->id && ITM[s->id].kind == K_PICK) {
    d = ITM[s->id].b; *tier = ITM[s->id].a;
    if (EN_T(s) == E_EFF) d += EN_L(s) * 2;
    if (ITM[s->id].a == 5) d += 4;
  }
  return d;
}
static void break_block(int tx, int ty, int o) {
  const BlockInfo *b = &BLK[o];
  Slot *s = &inv[P.sel];
  int fort = (s->id && ITM[s->id].kind == K_PICK && EN_T(s) == E_FORT) ? EN_L(s) : 0;
  if (o == O_TNT) { tnt_light(tx, ty); seto(tx, ty, 0); return; }
  if (o == O_NRACK) { if (rnd(100) < 15) gain(I_GOLD, 1); }
  else if (o == O_CHEST || o == O_DISPENSER || o == O_HOPPER) {
    int ci = chest_find(tx, ty, 0);
    if (ci >= 0) { for (int k = 0; k < 27; k++) if (chest_inv[ci][k].id) { gain(chest_inv[ci][k].id, chest_inv[ci][k].n); chest_inv[ci][k].id = 0; chest_inv[ci][k].n = 0; } chest_pos[ci] = 0; }
    gain(b->drop, 1);
  } else if (o == O_TREE || o == O_PINE || o == O_JTREE) {
    gain(I_WOOD, 1 + rnd(2));
    if (rnd(100) < 22) gain(I_APPLE, 1);
  } else if (o == O_PISTON || o == O_STICKY) {
    u8 st = wst[tidx(tx, ty)];
    if (st & 0x80) { int d = st & 3; if (geto(tx + DX[d], ty + DY[d]) == O_PHEAD) seto(tx + DX[d], ty + DY[d], 0); }
    gain(b->drop, 1);
  } else if (b->drop) {
    int n = b->dn;
    if (fort && (o == O_COAL || o == O_DIAM || o == O_RORE || o == O_LAPIS) && rnd(100) < fort * 33) n += 1 + rnd(fort);
    gain(b->drop, n);
  }
  if (b->xp) add_xp(b->xp);
  if (o == O_DSPAWN) { say("Generador roto!"); }
  if (o >= O_WHEAT0 && o <= O_CARROT3 && ((o - O_WHEAT0) % 4) == 3 && rnd(2)) gain(o >= O_CARROT0 ? I_CARROT : I_SEED, 1);
  wst[tidx(tx, ty)] = 0; wrs[tidx(tx, ty)] = 0;
  seto(tx, ty, 0);
  rs_neighbor_changed(tx, ty);
}

/* ------------------------------------------------------------- dormir */
static void try_sleep(void) {
  int night = day_t > DAY_LEN * 55 / 100 && day_t < DAY_LEN * 92 / 100;
  P.bed.x = PTX(); P.bed.y = PTY(); P.has_bed = 1;
  if (!night) { say("Cama guardada"); return; }
  day_t = DAY_LEN * 95 / 100; /* amanecer */
  P.hp = 20;
  say("Buenos dias!");
}

/* -------------------------------------------------------------------- A */
static void interact_block(int tx, int ty, int o) {
  int i = tidx(tx, ty);
  switch (o) {
  case O_LEVER: wst[i] ^= 0x80; render_tile(tx, ty); rs_neighbor_changed(tx, ty); break;
  case O_BUTTON: wst[i] |= 0x80; wrs[i] = 10; render_tile(tx, ty); rs_neighbor_changed(tx, ty); break;
  case O_REPEATER: { int d = ((wst[i] >> 2) & 3); d = (d + 1) & 3; wst[i] = (u8)((wst[i] & ~0x0C) | (d << 2)); say("Retardo"); break; }
  case O_COMPARATOR: wst[i] ^= 0x04; say(wst[i] & 4 ? "Modo restar" : "Modo comparar"); break;
  case O_CHEST: case O_DISPENSER: case O_HOPPER: ui_open(MN_CHEST, chest_find(tx, ty, 1)); break;
  case O_BED: try_sleep(); break;
  case O_ENCH: ui_open(MN_ENCH, 0); break;
  case O_BREW: ui_open(MN_CRAFT, 11); break;
  case O_FRAME: say("Usa un Ojo del End (B)"); break;
  default: break;
  }
}

void action_a(void) {
  if (P.cd > 0 || P.sleeping) return;
  int fx = PTX() + DX[P.dir], fy = PTY() + DY[P.dir];
  /* entidad delante */
  Ent *e = ent_at(PX() + DX[P.dir] * 12, PY() + DY[P.dir] * 12, 11);
  if (e) {
    P.swing = 8; P.cd = 18;
    if (e->type == M_VILLAGER) { ui_trade_open(e); return; }
    Slot *s = &inv[P.sel];
    const MobInfo *mi = &MOBS[e->type];
    if (mi->ai == AI_ANIMAL && s->id && (s->id == I_WHEAT || s->id == I_CARROT || s->id == I_SEED) && !(e->flags & EF_LOVE)) {
      e->flags |= EF_LOVE; e->t2 = 600; if (P.mode != MODE_CREATIVE) { s->n--; if (!s->n) s->id = 0; }
      say("Amor!"); return;
    }
    if (e->type == M_CAT) { if (s->id == I_COD || s->id == I_SALMON) { e->flags |= EF_TAME; if (P.mode != MODE_CREATIVE) { s->n--; if (!s->n) s->id = 0; } say("Gato domado"); } return; }
    int dmg, kb; held_dmg(&dmg, &kb);
    ent_damage(e, dmg, DX[P.dir] * kb, DY[P.dir] * kb);
    return;
  }
  int o = geto(fx, fy);
  if (o && (BLK[o].flags & BF_INT)) { P.cd = 14; interact_block(fx, fy, o); return; }
  if (o && (BLK[o].flags & BF_UNB)) { P.cd = 10; return; }
  if (o == 0) { P.mine_hp = 0; return; }
  /* minar */
  P.swing = 8; P.cd = 12;
  if (fx != P.mine_x || fy != P.mine_y || P.mine_hp <= 0) { P.mine_x = fx; P.mine_y = fy; P.mine_hp = BLK[o].hp; }
  int tier, d = mine_power(&tier);
  if (BLK[o].tier > tier) { say("Necesitas un pico mejor"); return; }
  Slot *s = &inv[P.sel];
  if (P.mode == MODE_CREATIVE) d = 99;
  P.mine_hp -= d;
  if (s->id && ITM[s->id].kind == K_PICK) wear(s, 1);
  if (P.mine_hp <= 0) { P.mine_hp = 0; break_block(fx, fy, o); }
}

/* -------------------------------------------------------------------- B */
static void check_portal_ring(int px, int py) {
  for (int cy = py - 1; cy <= py + 1; cy++)
    for (int cx = px - 1; cx <= px + 1; cx++) {
      if (geto(cx, cy) != 0 || !tile_walk(cx, cy)) continue;
      int ok = 1;
      for (int dy = -1; dy <= 1 && ok; dy++) for (int dx = -1; dx <= 1 && ok; dx++) if ((dx || dy) && geto(cx + dx, cy + dy) != O_OBS) ok = 0;
      if (ok) { seto(cx, cy, O_NPORTAL); if (cur_dim == D_OVER) { portal_over.x = cx; portal_over.y = cy; } say("Portal al Nether!"); return; }
    }
}
static void check_end_portal(int fx, int fy) {
  for (int cy = fy - 1; cy <= fy + 1; cy++)
    for (int cx = fx - 1; cx <= fx + 1; cx++) {
      int ok = 1, any = 0;
      for (int dy = -1; dy <= 1 && ok; dy++) for (int dx = -1; dx <= 1 && ok; dx++) if (dx || dy) { int o = geto(cx + dx, cy + dy); if (o != O_FRAMEF) ok = 0; any = 1; }
      if (ok && any) { seto(cx, cy, O_EPORTAL); say("Portal del End abierto!"); return; }
    }
}
static int near_water(int x, int y, int r) {
  for (int dy = -r; dy <= r; dy++) for (int dx = -r; dx <= r; dx++) if (is_water(x + dx, y + dy)) return 1;
  return 0;
}
static void spend(Slot *s) {
  if (P.mode == MODE_CREATIVE) return;
  s->n--;
  if (!s->n) { s->id = 0; s->en = 0; }
}

void use_item_b(void) {
  if (P.cd > 0 || P.sleeping) return;
  Slot *s = &inv[P.sel];
  int fx = PTX() + DX[P.dir], fy = PTY() + DY[P.dir];
  if (!s->id) return;
  const ItemInfo *it = &ITM[s->id];
  P.cd = 14;
  switch (it->kind) {
  case K_PLACE: {
    int o = geto(fx, fy);
    u8 g = getg(fx, fy);
    if (!tinb(fx, fy) || o) return;
    if (s->id == I_PLANK && (g == G_WATER || g == G_DEEP)) { setg(fx, fy, G_WOOD); spend(s); return; }
    if (g == G_WATER || g == G_DEEP || g == G_VOID) return;
    if (g == G_LAVA && s->id != I_COBBLE && s->id != I_OBSIDIAN) return;
    u8 blk = it->a;
    if (s->id == I_CORAL) blk = (u8)(O_CORALR + rnd(4));
    int px = PTX(), py = PTY();
    if (!(BLK[blk].flags & BF_WALK) && fx == px && fy == py) return;
    seto(fx, fy, blk);
    int i = tidx(fx, fy);
    wst[i] = 0; wrs[i] = 0;
    if (blk == O_REPEATER || blk == O_COMPARATOR || blk == O_PISTON || blk == O_STICKY || blk == O_OBSERVER || blk == O_DISPENSER || blk == O_HOPPER || blk == O_RTORCH) wst[i] = (u8)P.dir;
    if (blk == O_RTORCH) wst[i] |= 0x80;
    spend(s);
    tile_hook(fx, fy);
    rs_neighbor_changed(fx, fy);
    if (blk == O_OBS) check_portal_ring(fx, fy);
    return;
  }
  case K_FOOD:
    if (s->id == I_CARROT) {
      u8 g = getg(fx, fy);
      if ((g == G_SOIL || g == G_SOILW) && !geto(fx, fy)) { seto(fx, fy, O_CARROT0); spend(s); return; }
    }
    if (P.food >= 20 && P.hp >= 20) return;
    eat_item(s);
    return;
  case K_POTION: drink(s); return;
  case K_BOW:
    if (inv_count(I_ARROW) > 0) {
      if (P.mode != MODE_CREATIVE) inv_take(I_ARROW, 1);
      int dmg = 5 + (EN_T(s) == E_POWER ? EN_L(s) * 2 : 0) + (P.t_str > 0 ? 2 : 0);
      proj_spawn(1, P.x, P.y, DX[P.dir] * 56, DY[P.dir] * 56, dmg, 0);
      wear(s, 1);
      P.cd = 24;
    } else say("Sin flechas");
    return;
  case K_TOOL: {
    u8 g = getg(fx, fy);
    switch (it->a) {
    case 0: /* balde vacio */
      if (is_water(fx, fy)) { s->id = I_WBUCKET; setg(fx, fy, G_SAND); }
      else if (g == G_LAVA) { s->id = I_LBUCKET; setg(fx, fy, G_CAVE); }
      return;
    case 1: /* agua */
      if (g == G_LAVA) { setg(fx, fy, G_CAVE); seto(fx, fy, O_OBS); s->id = I_BUCKET; }
      else if (!geto(fx, fy) && tinb(fx, fy) && g != G_VOID) { setg(fx, fy, G_WATER); s->id = I_BUCKET; }
      return;
    case 2: /* lava */
      if (is_water(fx, fy)) { setg(fx, fy, G_CAVE); seto(fx, fy, O_OBS); s->id = I_BUCKET; }
      else if (!geto(fx, fy) && tinb(fx, fy) && g != G_VOID) { setg(fx, fy, G_LAVA); s->id = I_BUCKET; }
      return;
    case 3: P.block_t = 40; return; /* escudo */
    case 4: /* azada */
      if ((g == G_GRASS || g == G_DIRT || g == G_JGRASS || g == G_GRASSF1 || g == G_GRASSF2) && !geto(fx, fy)) {
        setg(fx, fy, near_water(fx, fy, 4) ? G_SOILW : G_SOIL);
        if (rnd(100) < 14) gain(I_SEED, 1);
        wear(s, 1);
      }
      return;
    case 5: /* semillas */
      if ((g == G_SOIL || g == G_SOILW) && !geto(fx, fy)) { seto(fx, fy, O_WHEAT0); spend(s); }
      return;
    case 6: /* cana */
      if (P.fish_t > 0 || P.fish_t < 0) {
        if (P.fish_t < 0) { /* pique! */
          int r = rnd(100);
          gain(r < 45 ? I_COD : r < 75 ? I_SALMON : r < 90 ? I_KELP : I_STICK, 1);
          add_xp(1); wear(s, 1);
        }
        P.fish_t = 0;
      } else if (is_water(fx, fy)) { P.fish_t = 180 + rnd(300); P.fish_x = (s16)fx; P.fish_y = (s16)fy; say("Esperando..."); }
      return;
    }
    return;
  }
  case K_SPECIAL:
    if (s->id == I_PEARL) {
      int tx = PTX(), ty = PTY(), k;
      for (k = 1; k <= 8; k++) if (!tile_walk(PTX() + DX[P.dir] * k, PTY() + DY[P.dir] * k)) break;
      k--;
      tx += DX[P.dir] * k; ty += DY[P.dir] * k;
      if (k > 0) { P.x = tx * 256 + 128; P.y = ty * 256 + 128; spend(s); player_hurt(2, PX(), PY()); }
    } else if (s->id == I_EYE) {
      if (geto(fx, fy) == O_FRAME) { seto(fx, fy, O_FRAMEF); spend(s); check_end_portal(fx, fy); }
      else if (cur_dim == D_CAVE) {
        int dx = 44 - PTX(), dy = 42 - PTY();
        say(dx * dx > dy * dy ? (dx > 0 ? "El ojo apunta al este" : "El ojo apunta al oeste") : (dy > 0 ? "El ojo apunta al sur" : "El ojo apunta al norte"));
      } else say("Funciona en las cuevas");
    } else if (s->id == I_CHORUS) {
      for (int k = 0; k < 12; k++) {
        int tx = PTX() + rnd(9) - 4, ty = PTY() + rnd(9) - 4;
        if (tile_walk(tx, ty) && !geto(tx, ty)) { P.x = tx * 256 + 128; P.y = ty * 256 + 128; break; }
      }
      P.hp += 1; if (P.hp > 20) P.hp = 20;
      spend(s);
    }
    return;
  default: return;
  }
}

/* ------------------------------------------------------------ actualizar */
void player_update(u16 held, u16 pressed) {
  (void)pressed;
  if (P.dead) return;
  /* movimiento */
  int dx = 0, dy = 0, nd = -1;
  if (held & KEY_LEFT) { dx = -1; nd = 1; }
  else if (held & KEY_RIGHT) { dx = 1; nd = 3; }
  if (held & KEY_UP) { dy = -1; nd = 2; }
  else if (held & KEY_DOWN) { dy = 1; nd = 0; }
  if (P.sleeping) { dx = dy = 0; }
  P.moving = (u8)(dx || dy);
  if (P.moving) {
    int sp = P.t_speed > 0 ? 28 : 19;
    if (dx && dy) sp = sp * 3 / 4;
    if (nd >= 0 && !(held & KEY_B) ) P.dir = (u8)nd;
    if (dx && box_free(P.x + dx * sp, P.y)) P.x += dx * sp;
    if (dy && box_free(P.x, P.y + dy * sp)) P.y += dy * sp;
    P.anim++;
  } else P.anim = 0;
  if (P.cd > 0) P.cd--;
  if (P.hurt > 0) P.hurt--;
  if (P.swing > 0) P.swing--;
  if (P.block_t > 0) P.block_t--;
  if (P.t_speed > 0) P.t_speed--;
  if (P.t_str > 0) P.t_str--;
  if (P.t_fire > 0) P.t_fire--;
  if (P.t_regen > 0) { P.t_regen--; if ((game_time & 63) == 0 && P.hp < 20) P.hp++; }
  if (P.t_night > 0) P.t_night--;
  if (P.t_res > 0) P.t_res--;
  int tx = PTX(), ty = PTY();
  int i = tidx(tx, ty);
  u8 g = wg[i], o = wo[i];
  /* lava */
  if (g == G_LAVA && P.t_fire == 0 && (game_time & 15) == 0) player_hurt(4, PX(), PY());
  /* pociones fuego */
  /* hambre */
  if (P.mode != MODE_CREATIVE) {
    P.hunger_t++;
    if (P.hunger_t > 1500) { P.hunger_t = 0; if (P.food > 0) P.food--; }
    if (P.food >= 16 && P.hp < 20) { P.regen_t++; if (P.regen_t > 200) { P.regen_t = 0; P.hp++; } }
    if (P.food <= 0) { P.regen_t++; if (P.regen_t > 260) { P.regen_t = 0; if (P.hp > 1 || P.mode == MODE_HARD) P.hp--; if (P.hp <= 0) P.dead = 1; } }
  }
  /* placas de presion */
  if (o == O_PLATE && !(wst[i] & 0x80)) { wst[i] |= 0x80; render_tile(tx, ty); rs_neighbor_changed(tx, ty); }
  /* portales */
  if (o == O_DOOR) {
    int k = 0;
    for (int j = 0; j < 3; j++) if (door_pt[j].x == tx && door_pt[j].y == ty) k = j;
    change_dim(D_CAVE, exit_pt[k].x, exit_pt[k].y + 2);
  } else if (o == O_EXIT) {
    int k = 0;
    for (int j = 0; j < 3; j++) if (exit_pt[j].x == tx && exit_pt[j].y == ty) k = j;
    change_dim(D_OVER, door_pt[k].x, door_pt[k].y + 2);
  } else if (o == O_NPORTAL || o == O_EPORTAL || o == O_XPORTAL) {
    P.portal_t++;
    if (P.portal_t > 70) {
      P.portal_t = 0;
      if (o == O_NPORTAL) {
        if (cur_dim == D_OVER) { portal_over.x = tx; portal_over.y = ty; change_dim(D_NETH, spawn_pt[D_NETH].x, spawn_pt[D_NETH].y); }
        else { int px = portal_over.x < 0 ? spawn_pt[D_OVER].x : portal_over.x, py = portal_over.x < 0 ? spawn_pt[D_OVER].y : portal_over.y + 2; change_dim(D_OVER, px, py); }
      } else if (o == O_EPORTAL) change_dim(D_END, spawn_pt[D_END].x, spawn_pt[D_END].y);
      else { change_dim(D_OVER, spawn_pt[D_OVER].x, spawn_pt[D_OVER].y); ui_open(MN_WIN, 0); }
    }
  } else P.portal_t = 0;
  /* pesca */
  if (P.fish_t > 0) { P.fish_t--; if (P.fish_t == 0) { P.fish_t = -90; say("Pica! pulsa B"); } }
  else if (P.fish_t < 0) { P.fish_t++; if (P.fish_t == 0) say("Se escapo"); }
  if (P.fish_t != 0 && (!is_water(P.fish_x, P.fish_y) || inv[P.sel].id != I_FROD)) P.fish_t = 0;
  /* aldea visitada */
  if (!stat_vis) for (int v = 0; v < vill_n; v++) { int ddx = tx - vill_pt[v].x, ddy = ty - vill_pt[v].y; if (cur_dim == D_OVER && ddx * ddx + ddy * ddy < 100) stat_vis = 1; }
  if (P.hp <= 0) P.dead = 1;
}
