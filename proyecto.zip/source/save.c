/* save.c - guardado en SRAM (2 ranuras de 16 KB). Se guarda la semilla + solo las casillas modificadas. */
#include "game.h"

int cur_slot;
#define SLOT_SZ 0x4000
#define MAGIC 0x49425543u /* 'CUBI' */

static volatile u8 *sp;
static void w8(u8 v) { *sp++ = v; }
static void w16(u16 v) { w8((u8)v); w8((u8)(v >> 8)); }
static void w32(u32 v) { w16((u16)v); w16((u16)(v >> 16)); }
static u8 r8(void) { return *sp++; }
static u16 r16(void) { u16 a = r8(); return (u16)(a | (r8() << 8)); }
static u32 r32(void) { u32 a = r16(); return a | ((u32)r16() << 16); }

int save_exists(int slot) {
  sp = SRAM + slot * SLOT_SZ;
  return r32() == MAGIC;
}
void save_erase(int slot) {
  sp = SRAM + slot * SLOT_SZ;
  w32(0);
}

void save_game(int slot) {
  cur_slot = slot;
  sp = SRAM + slot * SLOT_SZ;
  volatile u8 *end = SRAM + (slot + 1) * SLOT_SZ - 8;
  w32(MAGIC);
  w8(1); w8(P.mode); w8((u8)cur_dim); w8(P.won);
  w32(world_seed); w32(game_time); w32(day_t);
  w32((u32)P.x); w32((u32)P.y);
  w16((u16)P.hp); w16((u16)P.food); w32((u32)P.xp); w32((u32)P.lvl);
  w8(P.sel); w16((u16)P.bed.x); w16((u16)P.bed.y); w8((u8)P.has_bed);
  w32(ach_mask); w32((u32)stat_kills); w32((u32)stat_trades); w32((u32)stat_bred); w32((u32)stat_vis);
  w16((u16)portal_over.x); w16((u16)portal_over.y);
  for (int i = 0; i < INV_N; i++) { w8(inv[i].id); w8(inv[i].n); w8(inv[i].dur); w8(inv[i].en); }
  for (int c = 0; c < MAX_CHESTS; c++) {
    w16(chest_pos[c]);
    for (int k = 0; k < 27; k++) { w8(chest_inv[c][k].id); w8(chest_inv[c][k].n); w8(chest_inv[c][k].dur); w8(chest_inv[c][k].en); }
  }
  volatile u8 *cnt = sp;
  w16(0);
  int n = 0;
  for (int i = 0; i < TOTAL && sp + 5 < end; i++)
    if (wdirty[i >> 3] & (1 << (i & 7))) { w16((u16)i); w8(wg[i]); w8(wo[i]); w8(wst[i]); n++; }
  sp = cnt;
  w16((u16)n);
}

int load_game(int slot) {
  if (!save_exists(slot)) return 0;
  cur_slot = slot;
  sp = SRAM + slot * SLOT_SZ + 4;
  r8();
  int mode = r8(), dim = r8(), won = r8();
  u32 seed = r32(), gt = r32(), dt = r32();
  world_gen(seed);
  player_init(mode);
  for (int i = 0; i < INV_N; i++) { inv[i].id = 0; inv[i].n = 0; }
  P.x = (int)r32(); P.y = (int)r32();
  P.hp = (s16)r16(); P.food = (s16)r16(); P.xp = (int)r32(); P.lvl = (int)r32();
  P.sel = r8(); P.bed.x = (s16)r16(); P.bed.y = (s16)r16(); P.has_bed = r8();
  ach_mask = r32(); stat_kills = (int)r32(); stat_trades = (int)r32(); stat_bred = (int)r32(); stat_vis = (int)r32();
  portal_over.x = (s16)r16(); portal_over.y = (s16)r16();
  for (int i = 0; i < INV_N; i++) { inv[i].id = r8(); inv[i].n = r8(); inv[i].dur = r8(); inv[i].en = r8(); }
  for (int c = 0; c < MAX_CHESTS; c++) {
    chest_pos[c] = r16();
    for (int k = 0; k < 27; k++) { chest_inv[c][k].id = r8(); chest_inv[c][k].n = r8(); chest_inv[c][k].dur = r8(); chest_inv[c][k].en = r8(); }
  }
  int n = r16();
  for (int k = 0; k < n; k++) {
    int i = r16();
    if (i >= TOTAL) { sp += 3; continue; }
    wg[i] = r8(); wo[i] = r8(); wst[i] = r8();
    wdirty[i >> 3] |= (u8)(1 << (i & 7));
  }
  P.mode = (u8)mode; P.won = (u8)won; game_time = gt; day_t = dt;
  cur_dim = dim;
  return 1;
}
