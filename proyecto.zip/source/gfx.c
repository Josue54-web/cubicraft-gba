/* gfx.c - paleta global, pintor procedural de texturas, iconos y sprites */
#include "gfx.h"
#include "font.h"
#include "art.h"

u16 map_obj[1024] __attribute__((aligned(4)));
u16 map_gnd[1024] __attribute__((aligned(4)));
u16 map_hud[1024] __attribute__((aligned(4)));
u16 map_dark[1024] __attribute__((aligned(4)));
u16 oam_sh[512];
int map_dirty = 15;

/* ------------------------------------------------------------------ paleta */
/* P(r,s): color de las rampas antiguas, re-mapeado a la paleta de las texturas originales */
#define P(r, s) (ART_PM[1 + (r) * 8 + (s)])
static const u8 RAMP[30][6] __attribute__((unused)) = {
  {30, 30, 35, 235, 235, 240}, {60, 60, 70, 180, 180, 190}, {30, 70, 25, 140, 210, 90}, {60, 35, 15, 190, 140, 90},
  {130, 110, 60, 250, 240, 190}, {20, 50, 130, 150, 200, 250}, {120, 20, 10, 255, 230, 100}, {70, 40, 15, 210, 165, 100},
  {80, 10, 10, 240, 110, 100}, {35, 10, 15, 160, 60, 60}, {40, 20, 80, 190, 150, 230}, {110, 110, 70, 250, 250, 200},
  {140, 160, 190, 255, 255, 255}, {20, 80, 90, 170, 250, 245}, {110, 70, 10, 255, 235, 120}, {110, 80, 60, 240, 215, 190},
  {110, 60, 40, 250, 200, 160}, {20, 30, 90, 130, 160, 240}, {10, 80, 20, 130, 240, 110}, {110, 40, 70, 255, 170, 200},
  {10, 70, 70, 100, 220, 210}, {110, 90, 10, 255, 245, 110}, {80, 20, 90, 230, 110, 240}, {15, 45, 20, 80, 150, 60},
  {5, 5, 10, 70, 70, 85}, {60, 10, 30, 210, 70, 100}, {10, 50, 55, 70, 200, 190}, {30, 18, 8, 120, 80, 45},
  {150, 145, 135, 255, 252, 245}, {110, 50, 5, 255, 170, 60}};
static const u8 SPEC[15][3] = {{255, 255, 255}, {0, 0, 0}, {18, 20, 44}, {110, 110, 170}, {225, 28, 34}, {70, 70, 80},
                               {170, 110, 50}, {70, 210, 50}, {245, 225, 40}, {150, 150, 160}, {70, 200, 230}, {200, 60, 60},
                               {255, 255, 255}, {255, 255, 255}, {255, 255, 255}};
static u16 rgb(int r, int g, int b) { return (u16)((r >> 3) | ((g >> 3) << 5) | ((b >> 3) << 10)); }

static void pal_init(void) {
  /* 0 transparente, 1..240 colores de las texturas originales (tools/gen_art.py), 241..255 HUD */
  for (int i = 0; i < 241; i++) PAL[i] = ART_PAL[i];
  for (int i = 0; i < 15; i++) PAL[241 + i] = rgb(SPEC[i][0], SPEC[i][1], SPEC[i][2]);
  for (int i = 0; i < 256; i++) PAL[256 + i] = PAL[i];
}

/* ----------------------------------------------------------------- pintor */
static u8 cv[1024];
static int cw = 16, ch = 16;
static u32 rs = 1;
static int rn(void) {
  rs = rs * 1664525u + 1013904223u;
  return (int)((rs >> 16) & 255);
}
static void px(int x, int y, u8 c) {
  if (x >= 0 && y >= 0 && x < cw && y < ch) cv[y * cw + x] = c;
}
static void fill(u8 c) {
  for (int i = 0; i < cw * ch; i++) cv[i] = c;
}
static void rect(int x, int y, int w, int h, u8 c) {
  for (int j = 0; j < h; j++)
    for (int i = 0; i < w; i++) px(x + i, y + j, c);
}
static void speck(int r, int lo, int hi) {
  for (int i = 0; i < cw * ch; i++) cv[i] = P(r, lo + rn() % (hi - lo + 1));
}
static void dots(u8 c, int n, int x0, int y0, int w, int h) {
  while (n--) px(x0 + rn() % w, y0 + rn() % h, c);
}
static void blob(int cx, int cy, int rx, int ry, u8 c) {
  for (int y = cy - ry; y <= cy + ry; y++)
    for (int x = cx - rx; x <= cx + rx; x++) {
      int dx = x - cx, dy = y - cy;
      if (dx * dx * ry * ry + dy * dy * rx * rx <= rx * rx * ry * ry) px(x, y, c);
    }
}
static void line(int x0, int y0, int x1, int y1, u8 c) {
  int dx = x1 > x0 ? x1 - x0 : x0 - x1, dy = y1 > y0 ? y1 - y0 : y0 - y1;
  int sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1, e = dx - dy;
  for (;;) {
    px(x0, y0, c);
    if (x0 == x1 && y0 == y1) break;
    int e2 = 2 * e;
    if (e2 > -dy) { e -= dy; x0 += sx; }
    if (e2 < dx) { e += dx; y0 += sy; }
  }
}
static void bevel(int r) {
  for (int i = 0; i < 16; i++) {
    px(i, 0, P(r, 6)); px(0, i, P(r, 6));
    px(i, 15, P(r, 1)); px(15, i, P(r, 1));
  }
}
static void transpose(void) {
  u8 t[256];
  for (int y = 0; y < 16; y++)
    for (int x = 0; x < 16; x++) t[x * 16 + y] = cv[y * 16 + x];
  for (int i = 0; i < 256; i++) cv[i] = t[i];
}
static void stoneore(u8 c, int n) {
  speck(1, 3, 5);
  dots(c, n, 1, 1, 13, 13);
  for (int i = 0; i < n; i++) {
    int x = 1 + rn() % 12, y = 1 + rn() % 12;
    rect(x, y, 2, 2, c);
  }
  bevel(1);
}

/* copia un grafico 8bpp de la ROM (texturas originales) al lienzo */
static int rom_blit(u32 off, int w, int h) {
  if (!off) return 0;
  cw = w; ch = h;
  const u8 *p = ART_BLOB + off;
  for (int i = 0; i < w * h; i++) cv[i] = p[i];
  return 1;
}

/* ------------------------------------------------------------------ suelos */
static void art_ground(int g, int f) {
  cw = ch = 16;
  if (g == G_WATER && rom_blit(ART_W[f % 3], 16, 16)) return;
  if (g == G_LAVA && rom_blit(ART_L[f % 3], 16, 16)) return;
  if (rom_blit(ART_G[g], 16, 16)) return;
  rs = (u32)g * 7919u + 13u;
  switch (g) {
  case G_GRASS: speck(2, 3, 5); break;
  case G_GRASSF1:
  case G_GRASSF2: {
    speck(2, 3, 5);
    u8 c = g == G_GRASSF1 ? P(8, 5) : P(21, 6);
    px(5, 6, P(28, 6)); px(4, 6, c); px(6, 6, c); px(5, 5, c); px(5, 7, c);
    px(11, 11, P(28, 6)); px(10, 11, c); px(12, 11, c); px(11, 10, c); px(11, 12, c);
    break;
  }
  case G_DIRT: speck(3, 2, 4); break;
  case G_SAND: speck(4, 4, 6); break;
  case G_WATER:
  case G_DEEP: {
    fill(P(5, g == G_DEEP ? 2 : 3));
    for (int i = 0; i < 7; i++) {
      int x = rn() % 13, y = (rn() % 16 + f * 5) % 16;
      rect(x, y, 3, 1, P(5, 5)); px(x + 1, y, P(5, 7));
    }
    break;
  }
  case G_LAVA:
    fill(P(6, 3));
    for (int i = 0; i < 9; i++) {
      int x = rn() % 13, y = (rn() % 16 + f * 4) % 16;
      rect(x, y, 3, 2, P(6, 5)); px(x + 1, y, P(6, 7));
    }
    for (int i = 0; i < 5; i++) rect(rn() % 14, rn() % 15, 2, 1, P(6, 1));
    break;
  case G_CAVE: speck(1, 2, 4); break;
  case G_NETH: speck(9, 2, 4); break;
  case G_NBF:
    fill(P(9, 1));
    for (int y = 0; y < 16; y += 5) {
      rect(0, y, 16, 1, P(9, 0));
      for (int x = ((y / 5) & 1) * 4; x < 16; x += 8) rect(x, y, 1, 5, P(9, 0));
    }
    dots(P(9, 3), 10, 0, 0, 16, 16);
    break;
  case G_END: speck(11, 4, 6); break;
  case G_SBF:
    speck(1, 3, 4);
    for (int y = 0; y < 16; y += 8) {
      rect(0, y, 16, 1, P(1, 1));
      rect(((y / 8) & 1) * 8, y, 1, 8, P(1, 1));
    }
    break;
  case G_PBASE: speck(1, 4, 5); break;
  case G_SNOW: speck(12, 5, 7); break;
  case G_JGRASS:
    speck(2, 2, 4);
    dots(P(23, 3), 14, 0, 0, 16, 16);
    break;
  case G_PATH:
    speck(3, 4, 6);
    dots(P(1, 4), 6, 0, 0, 16, 16);
    break;
  case G_WOOD:
    fill(P(7, 4));
    for (int y = 0; y < 16; y += 4) {
      rect(0, y, 16, 1, P(7, 2));
      px((y * 3) & 15, y + 1, P(7, 2));
    }
    dots(P(7, 5), 8, 0, 0, 16, 16);
    break;
  case G_SOIL:
  case G_SOILW:
    speck(g == G_SOIL ? 3 : 27, 1, 3);
    for (int y = 3; y < 16; y += 4) rect(0, y, 16, 1, P(27, g == G_SOIL ? 1 : 0));
    if (g == G_SOILW) dots(P(5, 5), 4, 0, 0, 16, 16);
    break;
  default: fill(P(24, 0)); break;
  }
}

/* ----------------------------------------------------------------- objetos */
static void cobble(int r) {
  speck(r, 2, 4);
  for (int y = 0; y < 16; y += 5) {
    rect(0, y, 16, 1, P(r, 1));
    for (int x = ((y / 5) & 1) * 3; x < 16; x += 6) rect(x, y, 1, 5, P(r, 1));
  }
}
static void stalk(int x, int y0, int h, u8 c) { rect(x, y0, 1, h, c); }
static void torch(u8 f1, u8 f2) {
  rect(7, 7, 2, 8, P(7, 3)); rect(7, 4, 2, 3, f1); px(7, 3, f2); px(8, 4, f2);
}
static void art_obj(int o, int alt) {
  cw = ch = 16;
  if (rom_blit(alt && ART_OA[o] ? ART_OA[o] : ART_O[o], 16, 16)) return;
  rs = (u32)o * 4099u + 7u;
  fill(0);
  switch (o) {
  case O_TREE:
    rect(6, 10, 4, 6, P(7, 2)); rect(6, 10, 1, 6, P(7, 1));
    blob(8, 6, 7, 6, P(23, 3)); dots(P(23, 5), 14, 2, 1, 12, 10); dots(P(23, 1), 10, 2, 1, 12, 10);
    break;
  case O_PINE:
    rect(7, 12, 2, 4, P(7, 2));
    for (int k = 0; k < 3; k++) {
      int w = 3 + k * 2, y = 1 + k * 4;
      for (int j = 0; j < 5; j++) rect(8 - (w * (j + 1)) / 5 - 0, y + j, (w * (j + 1)) / 5 * 2, 1, P(23, 2 + (j > 2)));
      px(8, y, P(12, 6)); px(7, y + 1, P(12, 6));
    }
    break;
  case O_JTREE:
    rect(6, 9, 4, 7, P(7, 2));
    blob(8, 6, 8, 7, P(18, 2)); dots(P(18, 4), 16, 1, 0, 14, 12); dots(P(23, 1), 10, 1, 0, 14, 12);
    break;
  case O_CTREE: case O_WTREE: {
    int r = o == O_CTREE ? 25 : 26;
    rect(6, 9, 4, 7, P(r, 1)); blob(8, 6, 7, 6, P(r, 3)); dots(P(r, 5), 12, 2, 1, 12, 10);
    break;
  }
  case O_CACTUS:
    rect(5, 2, 6, 13, P(18, 3)); rect(2, 6, 3, 2, P(18, 3)); rect(2, 4, 2, 3, P(18, 3));
    rect(11, 8, 3, 2, P(18, 3)); rect(12, 6, 2, 3, P(18, 3)); rect(6, 2, 1, 13, P(18, 5));
    dots(P(28, 6), 10, 5, 2, 6, 12);
    break;
  case O_STONE: speck(1, 3, 5); bevel(1); break;
  case O_COAL: stoneore(P(24, 1), 5); break;
  case O_IRON: stoneore(P(15, 6), 5); break;
  case O_DIAM: stoneore(P(13, 6), 4); break;
  case O_RORE: stoneore(P(8, 5), 5); break;
  case O_LAPIS: stoneore(P(17, 4), 5); break;
  case O_OBS: speck(10, 0, 2); dots(P(10, 4), 12, 0, 0, 16, 16); bevel(10); break;
  case O_PLANK:
    fill(P(7, 4));
    for (int y = 0; y < 16; y += 4) { rect(0, y, 16, 1, P(7, 2)); px(4 + y, y + 2, P(7, 2)); }
    bevel(7);
    break;
  case O_COBB: cobble(1); break;
  case O_TORCH: torch(P(29, 6), P(21, 7)); break;
  case O_NRACK: speck(9, 3, 5); dots(P(9, 1), 8, 0, 0, 16, 16); bevel(9); break;
  case O_DOOR: case O_EXIT:
    speck(1, 1, 3); blob(8, 8, 5, 6, P(24, 0)); rect(3, 8, 10, 8, P(24, 0));
    if (o == O_EXIT) { rect(5, 12, 6, 1, P(1, 5)); rect(6, 10, 4, 1, P(1, 4)); }
    bevel(1);
    break;
  case O_NPORTAL:
    fill(P(10, 2));
    for (int i = 0; i < 40; i++) px(rn() & 15, rn() & 15, P(22, 2 + rn() % 4));
    break;
  case O_FRAME: case O_FRAMEF:
    speck(11, 1, 3); rect(4, 4, 8, 8, P(24, 1)); bevel(11);
    if (o == O_FRAMEF) { blob(8, 8, 3, 3, P(18, 5)); rect(7, 7, 2, 2, P(24, 0)); }
    break;
  case O_EPORTAL: case O_XPORTAL:
    fill(P(24, 0));
    for (int i = 0; i < 24; i++) px(rn() & 15, rn() & 15, o == O_EPORTAL ? P(18, 4 + rn() % 3) : P(10, 5 + rn() % 3));
    break;
  case O_GATE:
    fill(P(24, 1));
    for (int i = 0; i < 30; i++) px(rn() & 15, rn() & 15, P(10, 3 + rn() % 4));
    break;
  case O_BED:
    rect(1, 1, 14, 14, P(8, 4)); rect(1, 1, 14, 4, P(28, 6)); rect(2, 2, 5, 2, P(28, 7)); rect(1, 12, 14, 3, P(7, 2));
    bevel(8);
    break;
  case O_RBLOCK: speck(8, 3, 5); rect(3, 3, 3, 3, P(8, 7)); rect(9, 9, 3, 3, P(8, 7)); bevel(8); break;
  case O_RTORCH:
    rect(7, 7, 2, 8, P(7, 3));
    if (alt) { rect(7, 4, 2, 3, P(8, 6)); px(7, 3, P(8, 7)); px(8, 3, P(8, 7)); }
    else rect(7, 4, 2, 3, P(8, 1));
    break;
  case O_LEVER:
    rect(4, 10, 8, 5, P(1, 3));
    if (alt) line(8, 11, 12, 3, P(7, 5)); else line(8, 11, 4, 3, P(7, 5));
    rect(alt ? 12 : 3, 2, 2, 2, P(8, alt ? 7 : 3));
    break;
  case O_BUTTON:
    rect(4, 5, 8, 6, P(1, 4)); rect(5, 6, 6, 4, P(1, alt ? 3 : 5));
    break;
  case O_PLATE:
    rect(1, 3, 14, 11, P(1, alt ? 3 : 4)); rect(2, 4, 12, 9, P(1, alt ? 2 : 5)); break;
  case O_OBSERVER:
    speck(1, 3, 4); bevel(1);
    rect(4, 3, 8, 4, P(24, 1)); rect(5, 4, 2, 2, P(28, 7)); rect(9, 4, 2, 2, P(28, 7));
    rect(6, 10, 4, 4, alt ? P(8, 7) : P(8, 2));
    break;
  case O_WIRE:
    rect(7, 0, 2, 16, P(8, alt ? 6 : 2)); rect(0, 7, 16, 2, P(8, alt ? 6 : 2));
    if (alt) rect(7, 7, 2, 2, P(8, 7));
    break;
  case O_REPEATER: case O_COMPARATOR:
    rect(0, 0, 16, 16, P(1, 4)); rect(1, 1, 14, 14, P(1, 3));
    rect(3, 10, 2, 5, P(8, alt ? 6 : 2)); rect(11, 10, 2, 5, P(8, alt ? 6 : 2)); rect(7, 8, 2, 7, P(8, alt ? 6 : 2));
    rect(3, 3, 2, 3, P(8, alt ? 7 : 3)); rect(11, 3, 2, 3, P(8, alt ? 7 : 3));
    if (o == O_COMPARATOR) rect(7, 2, 2, 3, P(8, alt ? 7 : 3));
    line(8, 1, 6, 3, P(28, 6)); line(8, 1, 10, 3, P(28, 6));
    break;
  case O_PISTON: case O_STICKY:
    speck(1, 3, 4); rect(0, 0, 16, 5, o == O_STICKY ? P(18, 5) : P(7, 5)); rect(0, 4, 16, 1, P(7, 2));
    rect(6, 8, 4, 6, P(1, 1)); bevel(1);
    break;
  case O_PHEAD:
    rect(7, 4, 2, 12, P(7, 2)); rect(0, 0, 16, 5, P(7, 5)); rect(0, 4, 16, 1, P(7, 2));
    break;
  case O_LAMP:
    fill(P(21, alt ? 6 : 1)); rect(2, 2, 12, 12, P(21, alt ? 7 : 2)); bevel(21);
    break;
  case O_DISPENSER:
    speck(1, 3, 4); bevel(1); rect(4, 3, 8, 7, P(24, 0)); rect(7, 10, 2, 3, P(24, 0)); line(8, 1, 4, 3, P(28, 5)); line(8, 1, 12, 3, P(28, 5));
    break;
  case O_HOPPER:
    rect(1, 3, 14, 3, P(15, 2)); rect(3, 6, 10, 3, P(15, 1)); rect(5, 9, 6, 3, P(15, 2)); rect(6, 12, 4, 3, P(1, 2));
    rect(2, 3, 12, 1, P(24, 1));
    break;
  case O_CHEST:
    rect(1, 3, 14, 12, P(7, 3)); rect(1, 3, 14, 5, P(7, 4)); rect(1, 7, 14, 1, P(7, 1));
    rect(7, 6, 2, 4, P(14, 6)); bevel(7);
    break;
  case O_WHEAT0: case O_WHEAT1: case O_WHEAT2: case O_WHEAT3: {
    int k = o - O_WHEAT0;
    for (int x = 2; x < 16; x += 3) {
      stalk(x, 14 - (3 + k * 3), 3 + k * 3, P(18, 3 + (k > 1)));
      if (k == 3) { rect(x - 1, 2, 3, 4, P(21, 5)); px(x, 1, P(21, 7)); }
    }
    break;
  }
  case O_CARROT0: case O_CARROT1: case O_CARROT2: case O_CARROT3: {
    int k = o - O_CARROT0;
    for (int x = 3; x < 16; x += 5) {
      line(x, 13, x - 1, 13 - 2 - k * 2, P(18, 4)); line(x, 13, x + 1, 13 - 2 - k * 2, P(18, 3));
      if (k == 3) { rect(x - 1, 12, 3, 2, P(29, 6)); px(x, 14, P(29, 5)); }
    }
    break;
  }
  case O_SPRINK:
    rect(6, 6, 4, 9, P(15, 3)); rect(3, 2, 10, 5, P(5, 5)); rect(4, 3, 8, 3, P(5, 7)); px(2, 1, P(5, 7)); px(13, 1, P(5, 7));
    break;
  case O_HARV:
    rect(1, 1, 14, 14, P(15, 3)); bevel(15);
    for (int x = 2; x < 14; x += 3) rect(x, 11, 2, 4, P(24, 1));
    rect(5, 4, 6, 4, P(21, 5));
    break;
  case O_QORE: stoneore(P(28, 7), 5); for (int i = 0; i < 256; i++) if (cv[i] == P(1, 3) || cv[i] == P(1, 4) || cv[i] == P(1, 5)) cv[i] = P(9, 2 + (i & 1)); break;
  case O_NGOLD: stoneore(P(14, 6), 5); for (int i = 0; i < 256; i++) if (cv[i] == P(1, 3) || cv[i] == P(1, 4) || cv[i] == P(1, 5)) cv[i] = P(9, 2 + (i & 1)); break;
  case O_DEBRIS: speck(27, 1, 3); dots(P(27, 5), 14, 0, 0, 16, 16); bevel(27); break;
  case O_GLOWS: speck(21, 4, 7); dots(P(29, 5), 10, 0, 0, 16, 16); bevel(21); break;
  case O_BASALT: speck(1, 1, 3); for (int y = 0; y < 16; y += 4) rect(0, y, 16, 1, P(24, 2)); break;
  case O_WART:
    for (int i = 0; i < 6; i++) blob(2 + rn() % 12, 3 + rn() % 11, 1, 1, P(8, 3 + rn() % 3));
    break;
  case O_PURPUR: speck(10, 4, 6); rect(0, 7, 16, 1, P(10, 3)); rect(7, 0, 1, 16, P(10, 3)); bevel(10); break;
  case O_CHORUS:
    rect(7, 4, 2, 11, P(10, 3)); rect(4, 6, 3, 2, P(10, 3)); rect(9, 3, 3, 2, P(10, 3)); blob(8, 3, 2, 2, P(10, 6));
    break;
  case O_ENCH:
    rect(0, 6, 16, 10, P(24, 1)); rect(1, 2, 14, 6, P(8, 3)); rect(3, 1, 4, 4, P(28, 7)); rect(9, 1, 4, 4, P(28, 6)); rect(7, 1, 2, 4, P(8, 2));
    px(2, 12, P(13, 6)); px(13, 11, P(13, 6));
    break;
  case O_BREW:
    rect(6, 2, 4, 12, P(15, 3)); rect(1, 10, 14, 4, P(1, 3));
    rect(2, 6, 3, 5, P(13, 5)); rect(11, 6, 3, 5, P(13, 5)); rect(7, 2, 2, 3, P(29, 6));
    break;
  case O_CORALR: case O_CORALY: case O_CORALB: case O_CORALP: {
    int r = o == O_CORALR ? 8 : o == O_CORALY ? 21 : o == O_CORALB ? 17 : 22;
    for (int x = 3; x < 14; x += 3) { rect(x, 5 + (x & 3), 2, 10 - (x & 3), P(r, 4)); rect(x - 1, 4 + (x & 3), 4, 2, P(r, 6)); }
    break;
  }
  case O_KELP:
    for (int y = 0; y < 16; y++) { px(7 + ((y >> 2) & 1), y, P(18, 3)); px(8 + ((y >> 2) & 1), y, P(18, 4)); }
    break;
  case O_SEAGR:
    for (int x = 2; x < 15; x += 3) line(x, 15, x + ((x & 1) ? 1 : -1), 7 + (x & 3), P(18, 3 + (x & 1)));
    break;
  case O_PRISM: speck(20, 3, 6); rect(0, 7, 16, 1, P(20, 1)); rect(7, 0, 1, 16, P(20, 1)); bevel(20); break;
  case O_SPONGE: speck(21, 4, 6); for (int i = 0; i < 8; i++) rect(rn() % 14, rn() % 14, 2, 2, P(21, 2)); bevel(21); break;
  case O_GOLDB: speck(14, 5, 7); bevel(14); rect(3, 3, 3, 1, P(14, 7)); break;
  case O_WRECK:
    fill(P(27, 2));
    for (int y = 0; y < 16; y += 4) rect(0, y, 16, 1, P(27, 0));
    dots(P(27, 4), 8, 0, 0, 16, 16);
    break;
  case O_COBWEB:
    line(0, 0, 15, 15, P(28, 6)); line(15, 0, 0, 15, P(28, 6)); line(8, 0, 8, 15, P(28, 5)); line(0, 8, 15, 8, P(28, 5));
    blob(8, 8, 4, 4, 0); for (int a = 3; a < 6; a++) { px(8 - a, 8 - a + 1, P(28, 5)); px(8 + a, 8 - a, P(28, 5)); }
    break;
  case O_DSPAWN:
    speck(24, 0, 2); rect(1, 1, 14, 14, P(24, 0)); bevel(24);
    blob(8, 8, 3, 4, P(17, 5)); blob(8, 9, 1, 2, P(17, 7));
    break;
  case O_TNT:
    fill(P(8, 4)); rect(0, 5, 16, 6, P(28, 6));
    rect(3, 6, 2, 4, P(24, 1)); rect(7, 6, 2, 1, P(24, 1)); rect(7, 7, 2, 3, P(24, 1)); rect(11, 6, 2, 1, P(24, 1)); rect(11, 7, 1, 3, P(24, 1)); rect(12, 7, 1, 3, P(24, 1));
    bevel(8);
    break;
  case O_LANTERN:
    rect(4, 4, 8, 9, P(14, 6)); rect(5, 5, 6, 7, P(29, 7)); rect(6, 2, 4, 2, P(24, 2)); px(7, 1, P(24, 3));
    break;
  case O_SOULF:
    rect(5, 6, 6, 8, P(17, 5)); rect(6, 3, 4, 4, P(17, 6)); rect(7, 8, 2, 5, P(20, 7)); px(8, 2, P(17, 7));
    break;
  case O_MAGMA:
    fill(P(27, 0)); for (int i = 0; i < 6; i++) rect(rn() % 13, rn() % 14, 3, 2, P(6, 4 + rn() % 2)); dots(P(21, 6), 6, 0, 0, 16, 16);
    break;
  case O_MTN:
    speck(1, 1, 3);
    for (int i = 0; i < 5; i++) { int x = rn() % 12, y = rn() % 12; rect(x, y, 4, 1, P(1, 5)); rect(x + 1, y + 1, 2, 1, P(1, 4)); }
    break;
  case O_CAVEW: speck(24, 0, 2); dots(P(24, 3), 6, 0, 0, 16, 16); break;
  case O_NBW: speck(9, 0, 2); dots(P(9, 3), 6, 0, 0, 16, 16); break;
  case O_SBW: speck(1, 0, 2); for (int y = 0; y < 16; y += 4) rect(0, y, 16, 1, P(1, 0)); break;
  case O_BRICK:
    fill(P(8, 3));
    for (int y = 0; y < 16; y += 4) { rect(0, y, 16, 1, P(0, 5)); for (int x = ((y >> 2) & 1) * 4; x < 16; x += 8) rect(x, y, 1, 4, P(0, 5)); }
    break;
  case O_WELL:
    cobble(1); rect(3, 3, 10, 10, P(5, 4)); rect(4, 4, 8, 8, P(5, 3)); px(6, 6, P(5, 7));
    break;
  case O_ENDST: speck(11, 3, 5); dots(P(11, 7), 8, 0, 0, 16, 16); bevel(11); break;
  default: fill(P(22, 4)); break;
  }
}

/* ---------------------------------------------------------------- iconos */
static void ingot(u8 a, u8 b) { rect(3, 6, 10, 6, a); rect(4, 5, 9, 1, b); rect(3, 6, 10, 1, b); rect(3, 11, 10, 1, P(24, 2)); }
static void gem(u8 a, u8 b) { blob(8, 8, 5, 5, a); rect(5, 5, 3, 3, b); px(6, 6, P(28, 7)); }
static void bucket(u8 liq) {
  rect(3, 5, 10, 9, P(15, 3)); rect(4, 4, 8, 1, P(15, 5)); rect(4, 14, 8, 1, P(15, 2));
  if (liq) rect(4, 5, 8, 2, liq);
  px(3, 4, P(15, 5)); px(12, 4, P(15, 5));
}
static void art_item(int id) {
  cw = ch = 16;
  if (rom_blit(ART_I[id], 16, 16)) return;
  rs = (u32)id * 131u + 5u;
  fill(0);
  const ItemInfo *it = &ITM[id];
  int r = it->ramp;
  switch (it->kind) {
  case K_PLACE:
    if (id == I_REDSTONE) { rect(4, 6, 8, 5, P(8, 4)); dots(P(8, 7), 6, 4, 6, 8, 5); break; }
    if (id == I_CACTUS) { art_obj(O_CACTUS, 0); break; }
    if (id == I_BED) { art_obj(O_BED, 0); break; }
    art_obj(it->a, 0);
    break;
  case K_PICK:
    line(3, 14, 11, 6, P(7, 3)); line(4, 14, 12, 6, P(7, 2));
    blob(10, 5, 5, 2, P(r, 5)); rect(5, 3, 10, 2, P(r, 5)); px(4, 5, P(r, 4)); px(15, 6, P(r, 4)); rect(7, 3, 4, 1, P(r, 7));
    break;
  case K_SWORD:
    line(2, 14, 13, 3, P(r, 5)); line(3, 14, 14, 3, P(r, 6)); line(1, 15, 4, 12, P(7, 3)); line(5, 9, 8, 12, P(7, 4));
    px(14, 2, P(r, 7));
    break;
  case K_FOOD:
    if (id == I_APPLE) { blob(8, 9, 5, 5, P(8, 5)); rect(8, 2, 1, 3, P(7, 2)); px(10, 3, P(18, 5)); px(5, 7, P(8, 7)); }
    else if (id == I_BREAD) { rect(2, 6, 12, 7, P(4 + 0, 0 + 5)); rect(3, 5, 10, 2, P(7, 6)); line(5, 7, 6, 12, P(7, 3)); line(9, 7, 10, 12, P(7, 3)); }
    else if (id == I_CARROT) { line(4, 12, 11, 5, P(29, 6)); line(5, 12, 12, 5, P(29, 5)); line(11, 4, 12, 1, P(18, 4)); line(12, 5, 15, 3, P(18, 4)); }
    else if (id == I_COD || id == I_SALMON || id == I_CKFISH || id == I_CKSALMON) { blob(8, 8, 5, 3, P(r, 5)); rect(12, 5, 3, 6, P(r, 3)); px(5, 7, P(24, 1)); }
    else if (id == I_NSTAR) { blob(8, 8, 5, 5, P(28, 7)); rect(7, 2, 2, 12, P(28, 6)); rect(2, 7, 12, 2, P(28, 6)); }
    else if (id == I_DKELP) { rect(3, 4, 10, 9, P(r, 3)); dots(P(r, 1), 6, 3, 4, 10, 9); }
    else { blob(7, 8, 5, 4, P(r, 4)); rect(10, 9, 5, 3, P(28, 6)); px(14, 8, P(28, 6)); px(14, 12, P(28, 6)); rect(4, 6, 3, 2, P(r, 6)); }
    break;
  case K_ARMOR:
    rect(2, 2, 12, 12, P(r, 4)); rect(5, 2, 6, 3, 0); rect(0, 2, 3, 5, P(r, 4)); rect(13, 2, 3, 5, P(r, 4));
    rect(3, 3, 2, 10, P(r, 6)); rect(6, 5, 4, 8, P(r, 3)); rect(2, 13, 12, 1, P(r, 1));
    break;
  case K_BOW:
    for (int y = 1; y < 15; y++) { int d = y < 8 ? 8 - y : y - 7; px(10 - (7 - d) / 2 + (d > 4 ? -1 : 0), y, P(7, 4)); }
    line(10, 1, 10, 14, P(28, 5)); line(10, 8, 3, 8, P(28, 6)); px(2, 8, P(15, 6));
    break;
  case K_POTION:
    rect(6, 1, 4, 3, P(28, 4)); rect(5, 4, 6, 2, P(13, 5)); blob(8, 10, 5, 4, P(13, 5));
    blob(8, 11, 4, 3, P(r, 4)); rect(5, 9, 6, 1, P(r, 6)); px(5, 8, P(28, 7));
    break;
  case K_TOOL:
    if (id == I_BUCKET) bucket(0);
    else if (id == I_WBUCKET) bucket(P(5, 5));
    else if (id == I_LBUCKET) bucket(P(6, 5));
    else if (id == I_SHIELD) { rect(3, 2, 10, 9, P(7, 4)); rect(4, 11, 8, 2, P(7, 4)); rect(6, 13, 4, 1, P(7, 4)); rect(7, 2, 2, 11, P(15, 5)); rect(3, 6, 10, 2, P(15, 4)); bevel(7); }
    else if (id == I_HOE) { line(3, 14, 11, 4, P(7, 3)); line(4, 14, 12, 4, P(7, 2)); rect(9, 3, 6, 2, P(1, 5)); rect(13, 4, 2, 3, P(1, 5)); }
    else if (id == I_SEED) { dots(P(21, 5), 7, 3, 4, 10, 8); dots(P(18, 4), 4, 3, 4, 10, 8); }
    else if (id == I_FROD) { line(2, 14, 12, 3, P(7, 3)); line(12, 3, 14, 12, P(28, 5)); rect(13, 12, 2, 2, P(8, 5)); }
    else art_obj(O_PLANK, 0);
    break;
  case K_SPECIAL:
    blob(8, 8, 5, 5, P(r, 4)); blob(8, 8, 3, 3, P(r, 6)); rect(7, 7, 2, 2, P(24, 0));
    if (id == I_CHORUS) { for (int i = 0; i < 256; i++) cv[i] = cv[i] ? (u8)(P(10, 3 + (i & 3))) : 0; }
    break;
  default: /* K_MAT */
    switch (id) {
    case I_STICK: line(3, 14, 12, 3, P(7, 3)); line(4, 14, 13, 3, P(7, 4)); break;
    case I_ROD: line(3, 14, 12, 3, P(21, 4)); line(4, 14, 13, 3, P(29, 6)); break;
    case I_WOOD: rect(3, 3, 10, 10, P(7, 3)); blob(8, 8, 4, 4, P(7, 5)); blob(8, 8, 2, 2, P(7, 3)); rect(3, 3, 1, 10, P(7, 1)); break;
    case I_COAL: gem(P(24, 1), P(24, 3)); break;
    case I_IRON: ingot(P(15, 5), P(15, 7)); break;
    case I_GOLD: ingot(P(14, 5), P(14, 7)); break;
    case I_NETHERITE: ingot(P(27, 2), P(27, 4)); break;
    case I_DIAMOND: gem(P(13, 5), P(13, 7)); break;
    case I_EMERALD: gem(P(18, 5), P(18, 7)); break;
    case I_LAPIS: gem(P(17, 4), P(17, 6)); break;
    case I_QUARTZ: gem(P(28, 6), P(28, 7)); break;
    case I_SHARD: gem(P(20, 5), P(20, 7)); break;
    case I_FEATHER: line(3, 14, 13, 2, P(28, 6)); line(4, 14, 14, 3, P(28, 5)); rect(8, 3, 5, 5, P(28, 6)); break;
    case I_ARROW: line(2, 14, 13, 3, P(7, 4)); line(13, 3, 14, 2, P(1, 5)); rect(12, 2, 3, 2, P(1, 5)); line(2, 14, 4, 11, P(28, 6)); line(3, 14, 5, 12, P(28, 6)); break;
    case I_BONE: line(3, 13, 12, 4, P(28, 6)); rect(2, 12, 3, 3, P(28, 6)); rect(11, 2, 3, 3, P(28, 6)); break;
    case I_STRING: line(2, 3, 13, 13, P(28, 6)); line(3, 3, 14, 12, P(28, 5)); break;
    case I_VIAL: rect(6, 1, 4, 3, P(28, 4)); blob(8, 10, 5, 5, P(13, 4)); break;
    case I_WOOL: rect(2, 3, 12, 10, P(28, 6)); dots(P(28, 4), 10, 2, 3, 12, 10); break;
    case I_SLIME: blob(8, 8, 5, 5, P(18, 5)); blob(7, 7, 2, 2, P(18, 7)); break;
    case I_LEATHER: rect(3, 3, 10, 10, P(27, 4)); dots(P(27, 2), 8, 3, 3, 10, 10); break;
    default:
      blob(8, 9, 5, 4, P(r, 4)); dots(P(r, 6), 6, 4, 6, 8, 6); dots(P(r, 2), 5, 4, 6, 8, 6);
      if (id == I_WHEAT) { for (int x = 4; x < 13; x += 3) { line(x, 14, x, 3, P(21, 4)); rect(x - 1, 2, 3, 4, P(21, 6)); } }
      break;
    }
    break;
  }
}

/* ------------------------------------------------------------------ mobs */
static void humanoid(u8 skin, u8 shirt, u8 pants, u8 hair, int f, int dir) {
  /* dir: 0 abajo, 1 arriba, 2 izquierda/derecha */
  int lh = f ? 3 : 4;
  rect(5, 1, 6, 6, skin);
  if (dir == 1) rect(5, 1, 6, 6, hair);
  else {
    rect(5, 1, 6, 2, hair);
    if (dir == 0) { px(6, 4, P(24, 1)); px(9, 4, P(24, 1)); } else { px(5, 4, P(24, 1)); px(5, 1, hair); }
  }
  rect(4, 7, 8, 5, shirt);
  if (dir == 2) { rect(6, 7, 4, 5, shirt); rect(6, 8, 3, 4, skin); }
  else { rect(2, 7, 2, 5, skin); rect(12, 7, 2, 5, skin); }
  rect(5, 12, 3, lh, pants); rect(8, 12, 3, f ? 4 : 3, pants);
  rect(5, 12 + lh, 3, 1, P(24, 1)); rect(8, 12 + (f ? 4 : 3), 3, 1, P(24, 1));
}
static void quad(u8 body, u8 head, u8 leg, int f) {
  rect(3, 6, 10, 7, body); rect(4, 1, 8, 6, head);
  rect(3, 13, 2, f ? 3 : 2, leg); rect(11, 13, 2, f ? 2 : 3, leg); rect(6, 13, 2, f ? 2 : 3, leg); rect(8, 13, 2, f ? 3 : 2, leg);
  px(5, 3, P(24, 1)); px(10, 3, P(24, 1));
}
static void art_mob(int m, int f) __attribute__((unused));
static void art_mob(int m, int f) {
  cw = ch = 16;
  rs = (u32)m * 977u + 3u;
  fill(0);
  switch (m) {
  case M_COW:
    quad(P(27, 3), P(27, 3), P(27, 1), f); rect(5, 5, 6, 2, P(28, 6)); rect(4, 1, 1, 2, P(28, 6)); rect(11, 1, 1, 2, P(28, 6));
    rect(4, 7, 3, 3, P(28, 6)); rect(9, 9, 3, 3, P(28, 6));
    break;
  case M_PIG:
    quad(P(19, 5), P(19, 5), P(19, 3), f); rect(6, 4, 4, 3, P(19, 7)); px(7, 5, P(19, 2)); px(9, 5, P(19, 2)); break;
  case M_SHEEP:
    quad(P(28, 6), P(0, 6), P(0, 3), f); rect(4, 1, 8, 5, P(0, 5)); rect(3, 6, 10, 7, P(28, 7)); rect(4, 0, 8, 1, P(28, 6));
    px(5, 3, P(24, 1)); px(10, 3, P(24, 1));
    break;
  case M_CHICKEN:
    blob(8, 10, 4, 3, P(28, 7)); rect(6, 4, 4, 5, P(28, 7)); rect(7, 6, 2, 2, P(29, 6)); rect(7, 3, 2, 1, P(8, 5)); px(6, 5, P(24, 1)); px(9, 5, P(24, 1));
    rect(6, 13, 1, f ? 3 : 2, P(21, 5)); rect(9, 13, 1, f ? 2 : 3, P(21, 5));
    break;
  case M_ZOMBIE: humanoid(P(18, 3), P(17, 3), P(17, 2), P(23, 2), f, 0); rect(2, 7, 2, 3, P(18, 3)); break;
  case M_SKELETON:
    humanoid(P(28, 5), P(0, 5), P(0, 4), P(0, 6), f, 0); rect(5, 2, 6, 1, P(0, 7)); rect(6, 4, 1, 1, P(24, 0)); rect(9, 4, 1, 1, P(24, 0));
    rect(4, 8, 8, 1, P(24, 2)); rect(4, 10, 8, 1, P(24, 2));
    break;
  case M_VILLAGER:
    humanoid(P(16, 5), P(27, 4), P(27, 3), P(27, 2), f, 0); rect(7, 4, 2, 3, P(16, 4)); rect(4, 8, 8, 1, P(27, 6));
    break;
  case M_PIGLIN:
    humanoid(P(19, 4), P(14, 3), P(7, 2), P(27, 3), f, 0); rect(5, 5, 6, 2, P(19, 6)); px(5, 5, P(28, 7)); px(10, 5, P(28, 7));
    break;
  case M_ENDERMAN:
    rect(5, 0, 6, 5, P(24, 1)); rect(6, 2, 2, 1, P(22, 7)); rect(9, 2, 2, 1, P(22, 7));
    rect(4, 5, 8, 5, P(24, 1)); rect(2, 5, 2, 9, P(24, 1)); rect(12, 5, 2, 9, P(24, 1));
    rect(5, 10, 3, f ? 6 : 5, P(24, 1)); rect(8, 10, 3, f ? 5 : 6, P(24, 1));
    break;
  case M_CREEPER:
    rect(4, 1, 8, 7, P(18, 3)); rect(5, 8, 6, 4, P(18, 3)); rect(4, 12, 3, 3 + f, P(18, 2)); rect(9, 12, 3, 4 - f, P(18, 2));
    dots(P(18, 5), 12, 4, 1, 8, 11); rect(5, 3, 2, 2, P(24, 0)); rect(9, 3, 2, 2, P(24, 0)); rect(7, 5, 2, 3, P(24, 0)); rect(6, 7, 1, 2, P(24, 0)); rect(9, 7, 1, 2, P(24, 0));
    break;
  case M_BLAZE:
    rect(5, 1, 6, 5, P(21, 5)); rect(6, 3, 1, 1, P(24, 1)); rect(9, 3, 1, 1, P(24, 1)); rect(5, 1, 6, 1, P(29, 6));
    for (int k = 0; k < 3; k++) { rect(2 + (k + f) % 2 * 1, 7 + k * 3, 4, 1, P(21, 6)); rect(10 - (k + f) % 2, 8 + k * 3, 4, 1, P(21, 6)); rect(6, 7 + k * 3, 4, 2, P(29, 5)); }
    break;
  case M_CAT:
    blob(8, 11, 4, 3, P(29, 4)); rect(5, 4, 6, 5, P(29, 4)); px(5, 3, P(29, 4)); px(10, 3, P(29, 4)); px(6, 6, P(18, 6)); px(9, 6, P(18, 6));
    rect(12, 9 + f, 2, 4, P(29, 4)); rect(5, 13, 2, 2, P(29, 3)); rect(9, 13, 2, 2, P(29, 3));
    break;
  case M_SQUID:
    rect(4, 1, 8, 8, P(17, 3)); rect(5, 0, 6, 2, P(17, 4)); rect(5, 5, 2, 2, P(28, 7)); rect(9, 5, 2, 2, P(28, 7)); px(6, 6, P(24, 1)); px(10, 6, P(24, 1));
    for (int x = 4; x < 12; x += 2) rect(x, 9, 1, 5 + ((x + f) & 1), P(17, 2));
    break;
  default: fill(P(22, 4)); break;
  }
}
static void art_big(int m, int f) {
  cw = ch = 32;
  rs = 99;
  fill(0);
  if (m == M_GHAST) {
    rect(4, 2, 24, 22, P(28, 6)); rect(3, 4, 26, 18, P(28, 6)); rect(4, 2, 24, 1, P(28, 7));
    rect(8, 10, 5, 3, P(24, 1)); rect(19, 10, 5, 3, P(24, 1)); rect(12, 17, 8, 3, P(24, 1));
    for (int i = 0; i < 5; i++) rect(5 + i * 5, 24, 3, 5 + ((i + f) & 1) * 2, P(28, 5));
  } else {
    rect(11, 10, 10, 14, P(24, 1)); rect(12, 3, 8, 8, P(24, 1)); rect(10, 5, 2, 2, P(24, 1)); rect(20, 5, 2, 2, P(24, 1));
    rect(13, 6, 2, 2, P(22, 6)); rect(17, 6, 2, 2, P(22, 6)); rect(14, 9, 4, 2, P(10, 3));
    int w = f ? 3 : 0;
    for (int i = 0; i < 11; i++) { rect(1 + i / 2, 4 + i + w * (11 - i) / 11, 10 - i / 2, 2, P(24, 2 + (i & 1))); rect(21 + 0, 4 + i + w * (11 - i) / 11, 10 - i / 2, 2, P(24, 2 + (i & 1))); }
    rect(14, 24, 4, 7, P(24, 1));
  }
}
static void art_proj(int id) {
  cw = ch = 16;
  fill(0);
  if (id == S_ARROW) { line(8, 15, 8, 2, P(7, 4)); rect(7, 0, 3, 3, P(1, 5)); rect(6, 13, 5, 2, P(28, 6)); }
  else if (id == S_FIRE) { blob(8, 8, 4, 4, P(29, 5)); blob(8, 8, 2, 2, P(21, 7)); }
  else if (id == S_SPARK) { rect(7, 3, 2, 10, P(28, 7)); rect(3, 7, 10, 2, P(28, 7)); }
  else art_obj(O_TNT, 0);
}
static void art_player(int dir, int f) __attribute__((unused));
static void art_player(int dir, int f) {
  cw = ch = 16;
  fill(0);
  humanoid(P(16, 5), P(20, 4), P(17, 3), P(27, 3), f, dir == 0 ? 0 : dir == 1 ? 1 : 2);
}

/* ------------------------------------------------------------- subida a VRAM */
static void put16(volatile u16 *d, int i, u8 a, u8 b) { d[i] = (u16)(a | (b << 8)); }
/* canvas (cw x ch) -> tiles 8bpp consecutivos (orden fila de tiles) */
static void upload8(volatile u16 *dst) {
  int tw = cw / 8, th = ch / 8, o = 0;
  for (int ty = 0; ty < th; ty++)
    for (int tx = 0; tx < tw; tx++)
      for (int y = 0; y < 8; y++)
        for (int x = 0; x < 8; x += 2) {
          const u8 *s = &cv[(ty * 8 + y) * cw + tx * 8 + x];
          put16(dst, o++, s[0], s[1]);
        }
}
static volatile u16 *meta_ptr(int slot) { return VRAM16 + (slot * 256) / 2; }
static volatile u16 *obj_ptr(int slot) { return VRAM16 + (OBJ_VRAM_OFF + slot * 256) / 2; }

/* ---------------------------------------------------------- asignacion slots */
static u8 s_base[O_COUNT], s_alt[O_COUNT], s_side[O_COUNT], s_altside[O_COUNT];
static u8 g_slot[G_COUNT];
static int next_slot;

int gfx_ground_slot(u8 g) { return g_slot[g]; }

int gfx_obj_slot(u8 o, u8 alt, u8 dir, u8 *hflip, u8 *vflip) {
  *hflip = 0; *vflip = 0;
  int flags = BLK[o].flags;
  int a = (flags & BF_ALT) && alt;
  if (!(flags & BF_DIR)) return a ? s_alt[o] : s_base[o];
  /* dir: 0 abajo,1 izquierda,2 arriba,3 derecha (como DX/DY del juego: 0=down 1=left 2=up 3=right) */
  if (dir == 2) return a ? s_alt[o] : s_base[o];
  if (dir == 0) { *vflip = 1; return a ? s_alt[o] : s_base[o]; }
  if (dir == 3) *hflip = 1;
  return a ? s_altside[o] : s_side[o];
}

static void gen_obj_assets(void) {
  next_slot = 24;
  for (int o = 1; o < O_COUNT; o++) {
    int fl = BLK[o].flags;
    s_base[o] = (u8)next_slot++;
    art_obj(o, 0); upload8(meta_ptr(s_base[o]));
    if (fl & BF_ALT) { s_alt[o] = (u8)next_slot++; art_obj(o, 1); upload8(meta_ptr(s_alt[o])); }
    if (fl & BF_DIR) {
      s_side[o] = (u8)next_slot++; art_obj(o, 0); transpose(); upload8(meta_ptr(s_side[o]));
      if (fl & BF_ALT) { s_altside[o] = (u8)next_slot++; art_obj(o, 1); transpose(); upload8(meta_ptr(s_altside[o])); }
    }
  }
}

/* sprites de mobs: cache LRU de 36 entradas (2 slots c/u) en OBJ VRAM; se suben bajo demanda */
static struct { u8 m, v, f; u32 stamp; } pool[POOL_N];
static u32 pool_clock;
int gfx_mob_slot(int m, int dir, int f, u8 *hflip, u8 *tall) {
  int v = dir == 0 ? 0 : dir == 2 ? 1 : 2;
  *hflip = (dir == 3);
  *tall = ART_MOBH[m] == 32;
  f &= 1;
  int victim = 0;
  u32 best = 0xFFFFFFFFu;
  pool_clock++;
  for (int i = 0; i < POOL_N; i++) {
    if (pool[i].m == m && pool[i].v == v && pool[i].f == f) { pool[i].stamp = pool_clock; return S_POOL + i * 2; }
    if (pool[i].stamp < best) { best = pool[i].stamp; victim = i; }
  }
  pool[victim].m = (u8)m; pool[victim].v = (u8)v; pool[victim].f = (u8)f; pool[victim].stamp = pool_clock;
  if (rom_blit(ART_MOB[m][v][f], 16, ART_MOBH[m])) upload8(obj_ptr(S_POOL + victim * 2));
  return S_POOL + victim * 2;
}

void gfx_icon(int slot, u8 item) {
  if (item == 0) { cw = ch = 16; fill(0); } else art_item(item);
  upload8(obj_ptr(slot));
}
void gfx_block_icon(int slot, u8 obj) { art_obj(obj, 0); upload8(obj_ptr(slot)); }

void gfx_anim(int f) {
  art_ground(G_WATER, f % 3); upload8(meta_ptr(g_slot[G_WATER]));
  art_ground(G_LAVA, f % 3); upload8(meta_ptr(g_slot[G_LAVA]));
}

/* --------------------------------------------------------------- HUD (4bpp) */
static void tile4(int idx, const u8 *px16) { /* 64 pixeles (indices 0..15) -> 32 bytes */
  volatile u16 *d = VRAM16 + (0xC000 + idx * 32) / 2;
  for (int y = 0; y < 8; y++)
    for (int x = 0; x < 8; x += 4) d[y * 2 + x / 4] = (u16)(px16[y * 8 + x] | (px16[y * 8 + x + 1] << 4) | (px16[y * 8 + x + 2] << 8) | (px16[y * 8 + x + 3] << 12));
}
static void hud_tiles(void) {
  u8 t[64];
  for (int i = 0; i < 64; i++) t[i] = 0;
  tile4(0, t);
  for (int c = 0; c < 95; c++) {
    for (int i = 0; i < 64; i++) t[i] = 0;
    for (int y = 0; y < 8; y++)
      for (int x = 0; x < 8; x++)
        if (font8x8[c][y] & (0x80 >> x)) {
          t[y * 8 + x] = 1;
        }
    for (int y = 0; y < 8; y++)
      for (int x = 0; x < 8; x++)
        if (t[y * 8 + x] == 0 && ((x > 0 && t[y * 8 + x - 1] == 1) || (y > 0 && t[(y - 1) * 8 + x] == 1) || (x > 0 && y > 0 && t[(y - 1) * 8 + x - 1] == 1))) t[y * 8 + x] = 2;
    tile4(c + 1, t);
  }
  for (int i = 0; i < 64; i++) t[i] = 3;
  tile4(T_PANEL, t);
  /* corazones y comida: 8x8 */
  static const char *heart[8] = {"........", ".22..22.", "25522552", "25555552", "25555552", ".255552.", "..2552..", "...22..."};
  static const char *food[8] = {"........", "...22...", "..2772..", ".277772.", ".277772.", "..2772..", "...22...", "........"};
  for (int v = 0; v < 3; v++) {
    for (int y = 0; y < 8; y++)
      for (int x = 0; x < 8; x++) {
        char c = heart[y][x]; u8 p = 0;
        if (c == '2') p = 2;
        if (c == '5') p = v == 0 ? 5 : v == 1 ? (x < 4 ? 5 : 6) : 6;
        t[y * 8 + x] = p;
      }
    tile4(T_HEART + v, t);
    for (int y = 0; y < 8; y++)
      for (int x = 0; x < 8; x++) {
        char c = food[y][x]; u8 p = 0;
        if (c == '2') p = 2;
        if (c == '7') p = v == 0 ? 7 : v == 1 ? (x < 4 ? 7 : 6) : 6;
        t[y * 8 + x] = p;
      }
    tile4(T_FOOD + v, t);
  }
  /* oscuridad: patrones de puntos negros (color 2) */
  static const u16 pat[4] = {0x0401, 0xA5A5, 0xFBFE, 0xFFFF};
  for (int l = 0; l < 4; l++) {
    for (int y = 0; y < 8; y++)
      for (int x = 0; x < 8; x++) {
        int bit = (pat[l] >> ((y & 3) * 4 + (x & 3))) & 1;
        t[y * 8 + x] = bit ? 2 : 0;
      }
    tile4(T_DARK1 + l, t);
  }
  for (int i = 0; i < 64; i++) t[i] = (i / 8 > 2 && i / 8 < 5) ? 8 : 0;
  tile4(T_XPON, t);
  for (int i = 0; i < 64; i++) t[i] = (i / 8 > 2 && i / 8 < 5) ? 6 : 0;
  tile4(T_XPOFF, t);
  for (int i = 0; i < 64; i++) t[i] = 4;
  tile4(T_BORDER, t);
  for (int c = 1; c <= 15; c++) { for (int i = 0; i < 64; i++) t[i] = (u8)c; tile4(109 + c, t); }
}

/* -------------------------------------------------------------------- init */
void gfx_init(void) {
  REG_DISPCNT = 0x0080; /* pantalla en blanco forzada mientras se sube todo */
  pal_init();
  for (int i = 0; i < 0x8000; i++) VRAM16[i] = 0; /* 64KB BG */
  for (int i = 0; i < 0x4000; i++) VRAM16[(OBJ_VRAM_OFF) / 2 + i] = 0;
  for (int g = 1; g < G_COUNT; g++) {
    g_slot[g] = (u8)g;
    art_ground(g, 0);
    upload8(meta_ptr(g));
  }
  gen_obj_assets();
  hud_tiles();
  /* sprites fijos */
  for (int v = 0; v < 3; v++)
    for (int f = 0; f < 2; f++) { rom_blit(ART_PLAYER[v][f], 16, 32); upload8(obj_ptr(S_PLAYER + (v * 2 + f) * 2)); }
  art_big(M_GHAST, 0); upload8(obj_ptr(S_GHAST));
  art_big(M_DRAGON, 0); upload8(obj_ptr(S_DRAGON));
  art_big(M_DRAGON, 1); upload8(obj_ptr(S_DRAGON + 4));
  art_proj(S_ARROW); upload8(obj_ptr(S_ARROW)); transpose(); upload8(obj_ptr(S_ARROWH));
  art_proj(S_FIRE); upload8(obj_ptr(S_FIRE));
  art_proj(S_TNT); upload8(obj_ptr(S_TNT));
  art_proj(S_SPARK); upload8(obj_ptr(S_SPARK));
  /* anillo de seleccion */
  cw = ch = 16; fill(0);
  for (int i = 0; i < 16; i++) { px(i, 0, P(21, 7)); px(i, 15, P(21, 7)); px(0, i, P(21, 7)); px(15, i, P(21, 7)); px(i, 1, P(21, 5)); px(i, 14, P(21, 5)); px(1, i, P(21, 5)); px(14, i, P(21, 5)); }
  upload8(obj_ptr(S_RING));
  for (int i = 0; i < 1024; i++) map_obj[i] = map_gnd[i] = map_hud[i] = map_dark[i] = 0;
  map_dirty = 15;
  REG_BG0CNT = BGCNT(3, 0, 1, SB_OBJ, 0);
  REG_BG1CNT = BGCNT(3, 0, 1, SB_GND, 0);
  REG_BG2CNT = BGCNT(0, 3, 0, SB_HUD, 0);
  REG_BG3CNT = BGCNT(1, 3, 0, SB_DARK, 0);
  oam_clear();
  oam_flush();
  REG_DISPCNT = DCNT_MODE0 | DCNT_OBJ_1D | DCNT_BG0 | DCNT_BG1 | DCNT_BG2 | DCNT_BG3 | DCNT_OBJ;
}

/* ------------------------------------------------------------ mapas y OAM */
void mt_put(u16 *map, int mx, int my, int slot, int hflip, int vflip) {
  mx &= 15; my &= 15;
  int t = slot * 4;
  u16 a = (u16)t, b = (u16)(t + 1), c = (u16)(t + 2), d = (u16)(t + 3), tmp;
  if (hflip) { tmp = a; a = b; b = tmp; tmp = c; c = d; d = tmp; a |= 0x400; b |= 0x400; c |= 0x400; d |= 0x400; }
  if (vflip) { tmp = a; a = c; c = tmp; tmp = b; b = d; d = tmp; a |= 0x800; b |= 0x800; c |= 0x800; d |= 0x800; }
  u16 *p = &map[(my * 2) * 32 + mx * 2];
  p[0] = a; p[1] = b; p[32] = c; p[33] = d;
  map_dirty |= (map == map_obj) ? 1 : (map == map_gnd) ? 2 : (map == map_dark) ? 4 : 8;
}

static void copy32(volatile u32 *d, const u16 *s, int n16) {
  const u32 *q = (const u32 *)s;
  for (int i = 0; i < n16 / 2; i++) d[i] = q[i];
}
void gfx_flush_maps(void) {
  if (!map_dirty) return;
  if (map_dirty & 1) copy32((volatile u32 *)(VRAM16 + (SB_OBJ * 0x800) / 2), map_obj, 1024);
  if (map_dirty & 2) copy32((volatile u32 *)(VRAM16 + (SB_GND * 0x800) / 2), map_gnd, 1024);
  if (map_dirty & 4) copy32((volatile u32 *)(VRAM16 + (SB_DARK * 0x800) / 2), map_dark, 1024);
  if (map_dirty & 8) copy32((volatile u32 *)(VRAM16 + (SB_HUD * 0x800) / 2), map_hud, 1024);
  map_dirty = 0;
}

void oam_clear(void) {
  for (int i = 0; i < 128; i++) { oam_sh[i * 4] = 0x0200; oam_sh[i * 4 + 1] = 0; oam_sh[i * 4 + 2] = 0; oam_sh[i * 4 + 3] = 0; }
}
/* size: 0 = 8x8, 1 = 16x16, 2 = 32x32, 3 = 16x32. slot en unidades de 16x16 (256 bytes). Devuelve siguiente indice. */
int oam_put(int n, int x, int y, int slot, int size, int hflip, int vflip, int pri) {
  if (n >= 128) return n;
  if (x <= -32 || x >= 240 || y <= -32 || y >= 160) return n;
  int tile = slot * 8; /* 8bpp: 2 unidades por tile de 8x8, 4 tiles = 8 unidades */
  int shape = 0;
  if (size == 3) { shape = 0x8000; size = 2; } /* 16x32 */
  oam_sh[n * 4] = (u16)((y & 255) | 0x2000 | shape);
  oam_sh[n * 4 + 1] = (u16)((x & 511) | (hflip << 12) | (vflip << 13) | (size << 14));
  oam_sh[n * 4 + 2] = (u16)(tile | (pri << 10));
  return n + 1;
}
void oam_flush(void) { mcpy16(OAM16, oam_sh, 512); }
