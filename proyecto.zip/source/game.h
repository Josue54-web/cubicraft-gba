#ifndef GAME_H
#define GAME_H
#include "data.h"
#include "gfx.h"

/* ---------------------------------------------------------------- mundo */
enum { D_OVER, D_CAVE, D_NETH, D_END, NDIM };
#define TOTAL 26880
extern const u8 DW[NDIM], DH[NDIM];
extern const u16 DOFF[NDIM];
extern u8 wg[TOTAL], wo[TOTAL], wst[TOTAL], wrs[TOTAL];
extern u8 wdirty[TOTAL / 8 + 1];
extern int cur_dim;
extern u32 world_seed;
#define MW (DW[cur_dim])
#define MH (DH[cur_dim])

typedef struct { int x, y; } Pt;
extern Pt spawn_pt[NDIM];
extern Pt door_pt[3], exit_pt[3];
extern Pt vill_pt[4];
extern int vill_n;
extern Pt portal_over; /* ultimo portal del Nether usado en la superficie */

void world_gen(u32 seed);
int tinb(int x, int y);
int tidx(int x, int y);
u8 getg(int x, int y);
u8 geto(int x, int y);
void setg(int x, int y, u8 v);
void seto(int x, int y, u8 v);
void seto_raw(int dim, int x, int y, u8 v);
extern void (*tile_hook)(int x, int y);
int tile_walk(int x, int y); /* se puede pisar (ignora entidades) */
int hash_xy(int x, int y, int s);
int is_water(int x, int y);

/* ------------------------------------------------------------ inventario */
typedef struct { u8 id, n, dur, en; } Slot; /* en = tipo<<2 | nivel */
#define INV_N 36
#define MAX_CHESTS 12
extern Slot inv[INV_N];
extern Slot chest_inv[MAX_CHESTS][27];
extern u16 chest_pos[MAX_CHESTS];
#define EN_T(s) ((s)->en >> 2)
#define EN_L(s) ((s)->en & 3)

int inv_add(u8 id, int n);
int inv_count(u8 id);
int inv_take(u8 id, int n);
int inv_can_add(u8 id, int n);
int can_craft(const Recipe *r);
void do_craft(const Recipe *r);
int chest_find(int x, int y, int create);
void chest_loot(int ci);
const char *item_name(u8 id);

/* ---------------------------------------------------------------- jugador */
enum { MODE_SURV, MODE_CREATIVE, MODE_HARD };
typedef struct {
  int x, y; /* centro en 1/16 px */
  u8 dir;   /* 0 abajo 1 izquierda 2 arriba 3 derecha */
  s16 hp;   /* 0..20 */
  s16 food; /* 0..20 */
  int xp, lvl;
  u8 sel;
  u8 mode;
  u8 anim, moving;
  s16 cd, hurt, swing;
  s16 t_speed, t_str, t_fire, t_regen, t_night, t_res;
  s16 hunger_t, regen_t;
  int mine_x, mine_y, mine_hp;
  s16 mine_t;
  s16 portal_t;
  s16 sleeping;
  Pt bed;
  int has_bed;
  int bx, by;       /* ojo de ender / tp */
  s16 fish_t, fish_x, fish_y;
  u8 won;
  u8 dead;
  u8 block_t;       /* escudo */
} Player;
extern Player P;
extern u32 ach_mask;
extern int stat_kills, stat_trades, stat_bred, stat_vis;

#define PX() ((P.x) >> 4)
#define PY() ((P.y) >> 4)
#define PTX() ((P.x) >> 8)
#define PTY() ((P.y) >> 8)
extern const s8 DX[4], DY[4];

void player_init(int mode);
void player_update(u16 held, u16 pressed);
void player_hurt(int dmg, int sx, int sy);
void say(const char *s);
extern char msg_buf[40];
extern int msg_t;
void add_xp(int n);
int xp_need(int lvl);
void use_item_b(void);
void action_a(void);
void check_achievements(void);
void eat_item(Slot *s);
void respawn(void);
void change_dim(int dim, int x, int y);
void held_dmg(int *dmg, int *kb);
int armor_pct(void);
int has_gold_armor(void);
int rs_sprinkler_near(int x, int y);

/* --------------------------------------------------------------- entidades */
typedef struct {
  int x, y; /* centro 1/16 px */
  s16 t, t2;
  u8 type, dir, hp, anim, flags, aux, hurt, st;
} Ent;
#define MAXENT 36
extern Ent ents[MAXENT];
#define EF_ALIVE 1
#define EF_ANGRY 2
#define EF_LOVE 4
#define EF_FUSE 8
#define EF_TAME 16
Ent *ent_spawn(int type, int tx, int ty);
void ents_clear(void);
void ents_update(void);
void ents_populate(void);
void ent_damage(Ent *e, int dmg, int kx, int ky);
Ent *ent_at(int px, int py, int reach);
typedef struct { int x, y; s16 t; } Boom;
extern Boom booms[6];
extern Ent *boss;

typedef struct {
  int x, y;
  s16 vx, vy;
  u8 type, life, dmg, owner; /* type 0 libre,1 flecha,2 bola de fuego */
  u8 dir;
} Proj;
#define MAXPROJ 14
extern Proj projs[MAXPROJ];
void proj_spawn(int type, int x, int y, int vx, int vy, int dmg, int owner);
void projs_update(void);
void explode(int tx, int ty, int r, int dmg);
void tnt_light(int x, int y);
void tnt_update(void);

/* -------------------------------------------------------------- redstone */
void rs_tick(void);
void rs_neighbor_changed(int x, int y);
void rs_toggle(int x, int y);
void rs_press_plate(int x, int y);
extern int rs_dirty;

/* -------------------------------------------------------------- simulacion */
extern u32 game_time;  /* frames totales */
extern u32 day_t;      /* 0..DAY_LEN */
#define DAY_LEN 18000
extern int diff_hard;
void sim_world(void); /* cultivos, spawn, etc. */
int dark_level_ambient(void);
u32 rnd32(void);
int rnd(int n);
void rnd_seed(u32 s);

/* --------------------------------------------------------------------- UI */
enum { MN_NONE, MN_PAUSE, MN_INV, MN_CRAFT, MN_CHEST, MN_TRADE, MN_ENCH, MN_MAP, MN_ACH, MN_CREATIVE, MN_DEAD, MN_WIN, MN_SAVE, MN_HELP, MN_BREW };
extern int menu_kind;
void ui_open(int kind, int arg);
int ui_update(u16 pressed, u16 held);
void ui_draw_hud(void);
void render_world(void);
void render_full_redraw(void);
void render_tile(int x, int y);
void hud_text(int x, int y, const char *s);
void hud_clear(void);
void hud_fill_panel(void);
int title_screen(void);
void ui_trade_open(Ent *e);
extern Ent *trade_ent;

/* ------------------------------------------------------------------ guardado */
int save_exists(int slot);
void save_game(int slot);
int load_game(int slot);
void save_erase(int slot);
extern int cur_slot;

void game_init(void);
void game_frame(void);
void host_debug_cmd(const char *cmd, int a, int b);

#endif
