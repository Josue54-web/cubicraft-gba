#ifndef GFX_H
#define GFX_H
#include "data.h"

/* VRAM: tiles 8bpp en cb0-2 (192 metatiles 16x16), tiles 4bpp de HUD en cb3,
   mapas en sb28 (HUD) sb29 (objetos) sb30 (suelo) sb31 (oscuridad). */
#define SB_HUD 28
#define SB_OBJ 29
#define SB_GND 30
#define SB_DARK 31

/* tiles HUD (4bpp) */
#define T_BLANK 0
#define T_CHAR(c) ((c) - 32 + 1)
#define T_PANEL 96
#define T_HEART 97 /* +0 lleno, +1 medio, +2 vacio */
#define T_FOOD 100 /* +0 lleno, +1 medio, +2 vacio */
#define T_DARK1 103 /* 103..106 = oscuridad 1..4 */
#define T_XPON 107
#define T_XPOFF 108
#define T_BORDER 109

/* slots de sprites (16x16 = 8 unidades de tile OBJ) */
#define S_ICON 0     /* 0..8 hotbar, 9 anillo, 10/11 extra */
#define S_RING 9
#define S_PLAYER 12  /* 12..23: (vista*2+frame)*2, 16x32; vista 0 abajo 1 arriba 2 lado */
#define S_POOL 24    /* 24..95: cache de sprites de mobs (POOL_N entradas de 2 slots) */
#define POOL_N 36
#define S_GHAST 96   /* 32x32 */
#define S_DRAGON 100 /* 32x32 x2 frames (100, 104) */
#define S_ARROW 108
#define S_FIRE 109
#define S_TNT 110
#define S_SPARK 111
#define S_ARROWH 112

int gfx_mob_slot(int m, int dir, int f, u8 *hflip, u8 *tall);
void gfx_init(void);
void gfx_flush_maps(void);
void gfx_anim(int f);                        /* agua/lava animadas */
int gfx_ground_slot(u8 g);
int gfx_obj_slot(u8 o, u8 alt, u8 dir, u8 *hflip, u8 *vflip);
void gfx_icon(int slot, u8 item);            /* sube icono del objeto a un slot OBJ */
void gfx_block_icon(int slot, u8 obj);

extern u16 map_obj[1024], map_gnd[1024], map_hud[1024], map_dark[1024];
extern u16 oam_sh[512];
extern int map_dirty;

void oam_clear(void);
int oam_put(int n, int x, int y, int slot, int size, int hflip, int vflip, int pri);
void oam_flush(void);
void mt_put(u16 *map, int mx, int my, int slot, int hflip, int vflip);
#endif
